
// ================================================================================
// Telegram bot: t.me/imguisource_bot
// Telegram channel (ImGui Source): t.me/ImGui_Source_FIXNEY
// Telegram channel (shit src 🧨): t.me/il2cpp_src
// ================================================================================

#pragma once
#include "sdk/game/il2cpp/api.h"
#include "c_playermanager.h"
#include "c_playercontroller.h"
#include "c_movement_controller.h"
#include "c_aim_controller.h"
#include "c_weaponry_controller.h"
#include "c_weapon_controller.h"
#include "c_weapon_parameters.h"
#include "sdk/game/unity/includes.h"
#include "unity/camera.h"
#include "unity/type.h"
#include "unity/material.h"
#include "unity/c_shader.h"
#include "unity/c_renderer.h"
#include "unity/c_component.h"
#include "sdk/game/unity/photon/includes.h"
