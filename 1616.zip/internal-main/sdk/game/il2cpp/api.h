
// ================================================================================
// Source Distribution:
//   Bot:     https://t.me/imguisource_bot
//   Primary: https://t.me/ImGui_Source_FIXNEY (ImGui Source)
//   Second:  https://t.me/il2cpp_src (shit src 🧨)
// ================================================================================

#pragma once
#include "il2cpp.h"
#include "globals.hpp"

inline void *(*il2cpp_domain_get)();
inline void *(*il2cpp_domain_assembly_open)(void *, const char *);
inline void *(*il2cpp_assembly_get_image)(void *);
inline void *(*il2cpp_object_new)(void *);
inline void *(*il2cpp_class_from_name)(void *, const char *, const char *);
inline const char *(*il2cpp_class_get_name)(void *);
inline void *(*il2cpp_thread_attach)(void *);
inline MethodInfo *(*il2cpp_class_get_method_from_name)(void *, const char *, int);
inline void *(clazz_unity)(const char *a, const char *b);
inline void *(clazz_def)(const char *a, const char *b);

namespace dll
{
    inline void *charp;
    inline void *unity;
    inline void *generated;
}
inline MethodInfo *GetMethodFromClass(Il2CppClass *clz, const char *name, uint8_t parameters_count);
// Resolve a managed class by its short name.  The 1.0.0 build stores most of
// the gameplay classes in the generated assembly, while older helper classes
// live in Assembly-CSharp or UnityEngine.CoreModule.
void *resolve_class(const char *name, const char *namespaze = "");
void *il2cpp_domain_ready();
void init();
