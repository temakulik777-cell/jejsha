
// ================================================================================
// Сурс взят из бота @imguisource_bot
// Подпишись на ImGui Source: t.me/ImGui_Source_FIXNEY
// Подпишись на shit src 🧨: t.me/il2cpp_src
// ================================================================================

#pragma once
#include "api.h"
#include <unistd.h>
#include <thread>
#include <mutex>
#include <dlfcn.h>
#include <cstring>

static void *g_domain = nullptr;
static std::mutex g_domain_mutex;

void *il2cpp_domain_ready()
{
    if (!il2cpp_domain_get)
        return nullptr;

    if (!g_domain)
    {
        std::lock_guard<std::mutex> lock(g_domain_mutex);
        if (!g_domain)
        {
            g_domain = il2cpp_domain_get();
            LOGD("il2cpp domain=%p", g_domain);
        }
    }

    // IL2CPP calls from an arbitrary injector/worker thread are not valid until
    // that thread has been registered with the runtime.  Keep the attachment
    // thread-local so the render thread and UnityMain each register once.
    static thread_local void *attached_domain = nullptr;
    if (g_domain && attached_domain != g_domain && il2cpp_thread_attach)
    {
        il2cpp_thread_attach(g_domain);
        attached_domain = g_domain;
    }

    return g_domain;
}

void *img_to_asm(const char *assembly)
{
    if (!assembly || !il2cpp_domain_assembly_open || !il2cpp_assembly_get_image)
        return nullptr;

    void *domain = il2cpp_domain_ready();
    if (!domain)
        return nullptr;

    void *domain_asm = il2cpp_domain_assembly_open(domain, assembly);
    if (!domain_asm)
    {
        LOGD("assembly open failed: %s", assembly);
        return nullptr;
    }

    void *image = il2cpp_assembly_get_image(domain_asm);
    LOGD("assembly=%s asm=%p image=%p", assembly, domain_asm, image);
    return image;
}

MethodInfo *GetMethodFromClass(Il2CppClass *clz, const char *name, uint8_t parameters_count)
{
    // Il2CppClass/MethodInfo layouts changed in 1.0.0; always go through the
    // exported il2cpp API instead of dereferencing the old structures.
    if (il2cpp_class_get_method_from_name)
        return il2cpp_class_get_method_from_name(clz, name, parameters_count);
    return nullptr;
}

void *(clazz_unity)(const char *a, const char *b)
{
    return dll::unity ? il2cpp_class_from_name(dll::unity, a, b) : nullptr;
}

void *(clazz_def)(const char *a, const char *b)
{
    return dll::charp ? il2cpp_class_from_name(dll::charp, a, b) : nullptr;
}

static void *resolve_api(const char *symbol, uintptr_t rva)
{
    // Exported symbols are preferred; the stripped 1.0.0 binary may only expose
    // the disassembled offsets, so keep the RVA as the fallback.
    if (symbol)
    {
        if (void *exported = dlsym(RTLD_DEFAULT, symbol))
            return exported;
    }
    return base ? reinterpret_cast<void *>(base + rva) : nullptr;
}

void *resolve_class(const char *name, const char *namespaze)
{
    if (!name || !il2cpp_class_from_name)
        return nullptr;

    const char *ns = namespaze ? namespaze : "";

    // Most gameplay classes in the 1.0.0 dump belong to the generated assembly.
    // Try the known image handles first, then the remaining game assemblies.
    void *images[] = {
        dll::generated,
        dll::charp,
        dll::unity,
    };

    for (void *image : images)
    {
        if (!image)
            continue;
        if (void *klass = il2cpp_class_from_name(image, ns, name))
        {
            LOGD("resolve_class %s -> %p (cached image %p)", name, klass, image);
            return klass;
        }
    }

    static const char *assemblies[] = {
        "__Generated", "__Generated.dll",
        "Assembly-CSharp", "Assembly-CSharp.dll",
        "Axlebolt.Standoff.Game", "Axlebolt.Standoff.Game.dll",
        "Axlebolt.Standoff.Gameplay", "Axlebolt.Standoff.Gameplay.dll",
        "Axlebolt.Standoff.Gameplay.Player", "Axlebolt.Standoff.Gameplay.Player.dll",
        "Axlebolt.Standoff.Gameplay.Features", "Axlebolt.Standoff.Gameplay.Features.dll",
        "Axlebolt.NetCode.Framework", "Axlebolt.NetCode.Framework.dll",
        "UnityEngine.CoreModule", "UnityEngine.CoreModule.dll",
    };

    for (const char *assembly : assemblies)
    {
        void *image = img_to_asm(assembly);
        if (!image)
            continue;
        if (void *klass = il2cpp_class_from_name(image, ns, name))
        {
            LOGD("resolve_class %s -> %p (image=%s %p)", name, klass, assembly, image);
            return klass;
        }
    }

    LOGD("resolve_class %s failed", name);
    return nullptr;
}

void init()
{
    if (!base)
        return;

    static std::mutex init_mutex;
    static bool apis_resolved = false;

    std::lock_guard<std::mutex> lock(init_mutex);

    if (!apis_resolved)
    {
        il2cpp_domain_get = (decltype(il2cpp_domain_get))
            resolve_api("il2cpp_domain_get", c_offsets->il2cpp_domain_get);
        il2cpp_domain_assembly_open = (decltype(il2cpp_domain_assembly_open))
            resolve_api("il2cpp_domain_assembly_open", c_offsets->il2cpp_domain_assembly_open);
        il2cpp_assembly_get_image = (decltype(il2cpp_assembly_get_image))
            resolve_api("il2cpp_assembly_get_image", c_offsets->il2cpp_assembly_get_image);
        il2cpp_class_from_name = (decltype(il2cpp_class_from_name))
            resolve_api("il2cpp_class_from_name", c_offsets->il2cpp_class_from_name);
        il2cpp_object_new = (decltype(il2cpp_object_new))
            resolve_api("il2cpp_object_new", c_offsets->il2cpp_object_new);
        il2cpp_class_get_name = (decltype(il2cpp_class_get_name))
            resolve_api("il2cpp_class_get_name", lemming::offsets::il2cpp_api::kClassGetName);
        il2cpp_thread_attach = (decltype(il2cpp_thread_attach))
            resolve_api("il2cpp_thread_attach", lemming::offsets::il2cpp_api::kThreadAttach);
        il2cpp_class_get_method_from_name = (decltype(il2cpp_class_get_method_from_name))
            resolve_api("il2cpp_class_get_method_from_name", c_offsets->il2cpp_class_get_method_from_name);
        apis_resolved = true;
    }

    // Do not cache a null image: the injector can call init() while Unity is
    // still creating its domain, and a later render frame must retry.
    if (!dll::generated)
        dll::generated = img_to_asm(oxorany("__Generated"));
    if (!dll::generated)
        dll::generated = img_to_asm(oxorany("__Generated.dll"));

    if (!dll::charp)
        dll::charp = img_to_asm(oxorany("Assembly-CSharp"));
    if (!dll::charp)
        dll::charp = img_to_asm(oxorany("Assembly-CSharp.dll"));

    if (!dll::unity)
        dll::unity = img_to_asm(oxorany("UnityEngine.CoreModule"));
    if (!dll::unity)
        dll::unity = img_to_asm(oxorany("UnityEngine.CoreModule.dll"));
    if (!dll::unity)
        dll::unity = img_to_asm(oxorany("UnityEngine"));
}
