
// ================================================================================
// /// ========================================= ///
// /// Bot: @imguisource_bot
// /// ImGui Source: @ImGui_Source_FIXNEY
// /// shit src 🧨: @il2cpp_src
// /// ========================================= ///
// ================================================================================

#pragma once
class c_renderer;
#pragma pack(1)
class c_type
{
    public:
    c_type* get_type(monoString* asdad)
    {
        using a = c_type*(*)(monoString* c, const void* method);
        a b = reinterpret_cast<a>(base + c_offsets->get_type);
        return b ? b(asdad, nullptr) : nullptr;
    }

    monoArray<c_renderer *> * find_objects_of_type()
    {
        using a = monoArray<c_renderer *> *(*)(c_type* c, const void* method);
        a b = reinterpret_cast<a>(base + c_offsets->find_objects_of_type);
        return b ? b(this, nullptr) : nullptr;
    }

};
#pragma pack()