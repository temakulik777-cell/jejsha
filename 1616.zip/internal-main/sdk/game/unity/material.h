
// ================================================================================
// Сурс взят из бота @imguisource_bot
// Подпишись на ImGui Source: t.me/ImGui_Source_FIXNEY
// Подпишись на shit src 🧨: t.me/il2cpp_src
// ================================================================================

#pragma once

#pragma pack(1)
class c_shader;
class c_material
{
public:
    void *get_texture()
    {
        using a = void *(*)(c_material *, const void *);
        a b = reinterpret_cast<a>(base + c_offsets->get_texture);
        return b ? b(this, nullptr) : nullptr;
    }

    void set_texture(uintptr_t tex)
    {
        using a = void (*)(c_material *, uintptr_t poss, const void *);
        a b = reinterpret_cast<a>(base + c_offsets->set_texture);
        return b ? b(this, tex, nullptr) : (void)0;
    }

    void *get_shader()
    {
        using a = void *(*)(c_material *, const void *);
        a b = reinterpret_cast<a>(base + c_offsets->get_shader);
        return b ? b(this, nullptr) : nullptr;
    }

    void set_shader(void *s)
    {
        using a = void (*)(c_material *, void *poss, const void *);
        a b = reinterpret_cast<a>(base + c_offsets->set_shader);
        return b ? b(this, s, nullptr) : (void)0;
    }

    void new_material(c_shader *s)
    {
        using a = void (*)(c_material *, c_shader *poss, const void *);
        a b = reinterpret_cast<a>(base + c_offsets->new_material);
        return b ? b(this, s, nullptr) : (void)0;
    }

    void set_color(color_t c)
    {
        using a = void (*)(c_material *, color_t poss, const void *);
        a b = reinterpret_cast<a>(base + c_offsets->set_color);
        return b ? b(this, c, nullptr) : (void)0;
    }

    void set_int(monoString *name, int val)
    {
        using a = void (*)(c_material *, monoString *sdfds, int asssd, const void *);
        a b = reinterpret_cast<a>(base + c_offsets->set_int);
        return b ? b(this, name, val, nullptr) : (void)0;
    }

    void set_float(monoString *name, float val)
    {
        using a = void (*)(c_material *, monoString *sdfds, float asssd, const void *);
        a b = reinterpret_cast<a>(base + c_offsets->set_float);
        return b ? b(this, name, val, nullptr) : (void)0;
    }
};
#pragma pack()