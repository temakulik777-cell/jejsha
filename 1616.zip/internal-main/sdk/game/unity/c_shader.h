
// ================================================================================
// Telegram Hub: @imguisource_bot / ImGui Source @ImGui_Source_FIXNEY / shit src 🧨 @il2cpp_src
// ================================================================================

#pragma once

#pragma pack(1)
class c_shader {
    public:
    c_shader *find(monoString *name)
    {
        using a = c_shader *(*)(monoString *sdfds, const void *method);
        a b = reinterpret_cast<a>(base + c_offsets->find);
        return b ? b(name, nullptr) : nullptr;
    }
};
#pragma pack()