
// ================================================================================
// Release channel: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Second channel: t.me/il2cpp_src (shit src 🧨)
// Telegram bot: t.me/imguisource_bot
// ================================================================================

#pragma once
#pragma pack(1)
class c_transform
{
public:
    Vector3 get_position()
    {
        if (!this || !c_offsets)
            return Vector3{};

        uintptr_t addr = base + c_offsets->get_position;
        if (!addr)
            return Vector3{};

        using fn = Vector3 (*)(c_transform *, const void *);
        fn f = reinterpret_cast<fn>(addr);
        if (!f)
            return Vector3{};

        return f(this, nullptr);
    }

    void set_position(Vector3 pos)
    {
        if (!c_offsets)
            return;
        uintptr_t addr = base + c_offsets->set_position;
        using fn = void (*)(c_transform *, Vector3, const void *);
        fn f = reinterpret_cast<fn>(addr);
        if (f)
            f(this, pos, nullptr);
    }

    Vector3 get_forward()
    {
        if (!c_offsets)
            return {};
        uintptr_t addr = base + c_offsets->get_forward;
        using fn = Vector3 (*)(c_transform *, const void *);
        fn f = reinterpret_cast<fn>(addr);
        return f ? f(this, nullptr) : Vector3{};
    }

    Quaternion get_rotation()
    {
        if (!c_offsets)
            return {};
        uintptr_t addr = base + c_offsets->get_rotation;
        using fn = Quaternion (*)(c_transform *, const void *);
        fn f = reinterpret_cast<fn>(addr);
        return f ? f(this, nullptr) : Quaternion{};
    }

    Vector3 get_up()
    {
        if (!c_offsets)
            return {};
        uintptr_t addr = base + c_offsets->get_up;
        using fn = Vector3 (*)(c_transform *, const void *);
        fn f = reinterpret_cast<fn>(addr);
        return f ? f(this, nullptr) : Vector3{};
    }

    Vector3 get_euler_angles()
    {
        if (!c_offsets)
            return {};
        uintptr_t addr = base + c_offsets->get_euler_angles;
        using fn = Vector3 (*)(c_transform *, const void *);
        fn f = reinterpret_cast<fn>(addr);
        return f ? f(this, nullptr) : Vector3{};
    }

    void set_euler_angles(euler_angles_t pos)
    {
        if (!c_offsets)
            return;
        uintptr_t addr = base + c_offsets->set_euler_angles;
        using fn = void (*)(c_transform *, euler_angles_t, const void *);
        fn f = reinterpret_cast<fn>(addr);
        if (f)
            f(this, pos, nullptr);
    }
};
#pragma pack()