
// ================================================================================
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Telegram Bot: t.me/imguisource_bot
// ImGui Source: t.me/ImGui_Source_FIXNEY
// shit src 🧨: t.me/il2cpp_src
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ================================================================================

#pragma once
class c_transform;
#pragma pack(1)
class c_component 
{
    public:
    c_transform *get_transform(void *c)
    {
        using a = c_transform*(*)(void* css, const void* method);
        a b = reinterpret_cast<a>(base + c_offsets->get_transform);
        return b ? b(c, nullptr) : nullptr;
    }

    void *get_game_object()
    {
        using a = void*(*)(c_component *a, const void* method);
        a b = reinterpret_cast<a>(base + c_offsets->get_game_object);
        return b ? b(this, nullptr) : nullptr;
    }

    // void set_enabled(c_transform *c)
    // {
    //     using a = void(*)(c_transform*css, bool);
    //     a b = reinterpret_cast<a>(base + c_offsets->set_enabled);
    //     return b(c, true);
    // }
    //
    // monoString *get_tag()
    // {
    //     using a = monoString*(*)(c_component *a);
    //     a b = reinterpret_cast<a>(base + c_offsets->get_tag);
    //     return b ? b(this, nullptr) : nullptr;
    // }
};
#pragma pack()