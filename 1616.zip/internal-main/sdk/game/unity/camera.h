
// ================================================================================
// Package distributed via @imguisource_bot
// Channel ImGui Source: @ImGui_Source_FIXNEY
// Channel shit src 🧨: @il2cpp_src
// ================================================================================

#pragma once

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstring>
#include <mutex>
#include <cstdint>
#include <sys/prctl.h>
#include <unistd.h>

#include "includes/egl/memory.hpp"

struct camera_snapshot_t
{
    std::mutex mutex;
    Matrix world_to_camera{};
    Matrix projection{};
    std::uintptr_t native{};
    bool ready{};
};

inline camera_snapshot_t g_camera_snapshot;

#pragma pack(1)
class c_camera
{
public:

    // Native Camera* (1.0.0).  This getter must only be called from the game
    // thread (ake::opmn hook), never from the EGL/ImGui render thread.
    void *get_native_main()
    {
        if (!base)
            return nullptr;
        using fn = void *(*)();
        fn f = reinterpret_cast<fn>(base + game_offsets::unity::kNativeCameraGetMain);
        return f ? f() : nullptr;
    }

    static bool is_unity_main()
    {
        char name[16]{};
        if (prctl(PR_GET_NAME, name, 0, 0, 0) != 0)
            return false;
        return std::strncmp(name, "UnityMain", 9) == 0;
    }

    static bool read_native(uintptr_t address, void *out, size_t size)
    {
        return address && out && size &&
               memory::perform_mem_rw(address, out, size, false);
    }

    static bool finite_matrix(const Matrix &m)
    {
        const float *v = reinterpret_cast<const float *>(&m);
        float magnitude = 0.0f;
        for (int i = 0; i < 16; ++i)
        {
            if (!std::isfinite(v[i]) || std::fabs(v[i]) > 1000000.0f)
                return false;
            magnitude += std::fabs(v[i]);
        }
        return magnitude > 0.01f;
    }

    static bool plausible_view(const Matrix &m)
    {
        // Unity view matrices have a rigid last row (m30..m33).
        return finite_matrix(m) &&
               std::fabs(m.m30) < 0.001f &&
               std::fabs(m.m31) < 0.001f &&
               std::fabs(m.m32) < 0.001f &&
               std::fabs(m.m33 - 1.0f) < 0.01f;
    }

    static bool plausible_projection(const Matrix &m)
    {
        return finite_matrix(m) &&
               std::fabs(m.m00) > 0.001f &&
               std::fabs(m.m11) > 0.001f;
    }

    // Captures the two native matrix caches while executing on UnityMain.  The
    // render thread only reads this snapshot, so a stale/freed camera can never
    // turn into a render-thread SIGSEGV.
    void capture_snapshot()
    {
        // ake::opmn is expected on UnityMain, but never trust the caller: a
        // managed camera pointer must not be dereferenced from a worker thread.
        if (!is_unity_main())
            return;

        using clock = std::chrono::steady_clock;
        static clock::time_point last_capture{};
        const auto now = clock::now();
        if (now - last_capture < std::chrono::milliseconds(16))
            return;
        last_capture = now;

        void *cam = get_native_main();
        if (!cam || !base)
            return;

        const uintptr_t address = reinterpret_cast<uintptr_t>(cam);
        uintptr_t vtable_before = 0;
        uintptr_t game_object_before = 0;
        if (!read_native(address, &vtable_before, sizeof(vtable_before)) ||
            !read_native(address + 0x20, &game_object_before, sizeof(game_object_before)))
            return;

        if (vtable_before < base + game_offsets::elf::kDataRelRoBegin ||
            vtable_before >= base + game_offsets::elf::kDataEnd ||
            !game_object_before)
            return;

        Matrix view{};
        Matrix projection{};
        if (!read_native(address + game_offsets::managed::kNativeCameraWorldToCameraMatrix,
                         &view, sizeof(view)) ||
            !read_native(address + game_offsets::managed::kNativeCameraProjectionMatrix,
                         &projection, sizeof(projection)))
            return;

        // Reject a camera that was replaced/freed during the two copies.
        uintptr_t vtable_after = 0;
        uintptr_t game_object_after = 0;
        if (!read_native(address, &vtable_after, sizeof(vtable_after)) ||
            !read_native(address + 0x20, &game_object_after, sizeof(game_object_after)) ||
            vtable_after != vtable_before || game_object_after != game_object_before)
            return;

        if (!plausible_view(view) || !plausible_projection(projection))
            return;

        std::lock_guard<std::mutex> lock(g_camera_snapshot.mutex);
        g_camera_snapshot.world_to_camera = view;
        g_camera_snapshot.projection = projection;
        g_camera_snapshot.native = address;
        g_camera_snapshot.ready = true;
    }

    Matrix get_world_to_camera_matrix()
    {
        std::lock_guard<std::mutex> lock(g_camera_snapshot.mutex);
        return g_camera_snapshot.ready ? g_camera_snapshot.world_to_camera : Matrix{};
    }

    Matrix get_projection_matrix()
    {
        std::lock_guard<std::mutex> lock(g_camera_snapshot.mutex);
        return g_camera_snapshot.ready ? g_camera_snapshot.projection : Matrix{};
    }

    bool has_snapshot()
    {
        std::lock_guard<std::mutex> lock(g_camera_snapshot.mutex);
        return g_camera_snapshot.ready;
    }

    void *get_main()
    {
        if (!base || !c_offsets->get_main)
            return nullptr;
        using a = void *(*)();
        a b = reinterpret_cast<a>(base + c_offsets->get_main);
        return b ? b() : nullptr;
    }

    void set_fov(float c)
    {
        if (!base || !c_offsets->set_fov)
            return;
        using a = void(*)(void*, float afd);
        a b = reinterpret_cast<a>(base + c_offsets->set_fov);
        if (b)
            b((void*)this, c);
    }

    Matrix get_projection_matrix_injected() {
        Matrix ret{};
        if (!base || !c_offsets->get_projection_matrix_injected)
            return ret;
        using a = void(*)(c_camera*, Matrix&);
        a b = reinterpret_cast<a>(base + c_offsets->get_projection_matrix_injected);
        if (b)
            b(this, ret);
        return ret;
    }

    Matrix get_world_to_camera_matrix_injected() {
        Matrix ret{};
        if (!base || !c_offsets->fsdfds)
            return ret;
        using a = void(*)(c_camera*, Matrix&);
        a b = reinterpret_cast<a>(base + c_offsets->fsdfds);
        if (b)
            b(this, ret);
        return ret;
    }
};
#pragma pack()
