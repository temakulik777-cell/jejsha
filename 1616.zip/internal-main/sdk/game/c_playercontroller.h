
// ================================================================================
// Source code from @imguisource_bot
// Primary: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Secondary: t.me/il2cpp_src (shit src 🧨)
// ================================================================================

#pragma once
#include <cstdint>
#include "globals.hpp"
#include "sdk/game/unity/c_transform.h"
#include "sdk/game/unity/c_renderer.h"

// Standoff 2 1.0.0 player architecture.
//
// The old PlayerController was split into a NetObject (mfc) + component/part
// containers (wmz/rct).  ake is the concrete player NetObject.  Everything in
// this header uses the dump-confirmed 1.0.0 layout from
// includes/offsets_1_0_0.hpp.

enum class team_t : uint8_t
{
    none = 0,
    tr = 1,
    ct = 2,
    spectator = 3,
};

void *resolve_class(const char *name, const char *namespaze);

namespace sdk1
{
inline void *typeinfo(uintptr_t slot)
{
    if (!slot || !base)
        return nullptr;

    // The script.json slots in this protected 1.0.0 build are not populated
    // with the Il2CppClass pointers that the old project expected.  Resolve the
    // small set of classes used by the port through the IL2CPP name API and
    // cache the result.  The slot read remains a fallback for builds where the
    // metadata usage table is populated normally.
    struct class_slot
    {
        uintptr_t slot;
        const char *name;
    };
    static const class_slot slots[] = {
        {game_offsets::typeinfo::kPlayer, "ake"},
        {game_offsets::typeinfo::kNetObject, "mfc"},
        {game_offsets::typeinfo::kModel, "jgi"},
        {game_offsets::typeinfo::kActor, "stn"},
        {game_offsets::typeinfo::kWeaponPart, "nrk"},
        {game_offsets::typeinfo::kWeaponInstance, "qjf"},
        {game_offsets::typeinfo::kStats, "ylw"},
        {game_offsets::typeinfo::kClientWorld, "njh"},
        {game_offsets::typeinfo::kRegistry, "gat"},
        {game_offsets::typeinfo::kStore, "gzx"},
        {game_offsets::typeinfo::kTransforms, "dwc"},
    };
    static void *resolved[sizeof(slots) / sizeof(slots[0])]{};
    static bool attempted[sizeof(slots) / sizeof(slots[0])]{};

    for (size_t i = 0; i < sizeof(slots) / sizeof(slots[0]); i++)
    {
        if (slots[i].slot != slot)
            continue;

        // A failed lookup used to be retried for every part/component of every
        // player on every update.  Each retry opened every game assembly and
        // logged its failures, which alone was enough to tank the frame rate.
        // Resolve each slot once; the metadata slot read below still remains as
        // a cheap per-call fallback.
        if (!resolved[i] && !attempted[i])
        {
            attempted[i] = true;
            resolved[i] = resolve_class(slots[i].name, "");
            if (!resolved[i])
                LOGD("typeinfo: %s unresolved, using slot fallback", slots[i].name);
        }
        if (resolved[i])
            return resolved[i];
        break;
    }

    void *value = *(void **)(base + slot);
    if (reinterpret_cast<uintptr_t>(value) < 0x100000000ULL)
        return nullptr;
    return value;
}

inline bool same_class(void *object, uintptr_t slot)
{
    if (!object)
        return false;
    void *wanted = typeinfo(slot);
    if (!wanted)
        return false;

    void *klass = *(void **)object;
    using get_parent_fn = void *(*)(void *);
    auto get_parent = reinterpret_cast<get_parent_fn>(base + game_offsets::il2cpp_api::kClassGetParent);

    for (int depth = 0; klass && depth < 24; depth++)
    {
        if (klass == wanted)
            return true;
        klass = get_parent(klass);
    }
    return false;
}
} // namespace sdk1

#pragma pack(1)
class c_stats
{
public:
    char pad0[0x10];
    uint16_t hp;       // 0x10
    uint16_t unk12;    // 0x12
    uint16_t max_hp;   // 0x14
    uint16_t armor;    // 0x16
    uint16_t unk18;    // 0x18
    uint16_t max_armor;// 0x1A
    bool helmet;       // 0x1C
    char pad1d[3];
    float unk20;       // 0x20

    int health() const { return hp; }
    int max_health() const { return max_hp; }
    int armor_value() const { return armor; }
    int max_armor_value() const { return max_armor; }
    bool has_helmet() const { return helmet; }
};

class c_character_bindings
{
public:
    char pad0[0x20];
    void *bones;              // 0x20 BonesDictionary
    void *tool;               // 0x28 GameObject
    void *animator;           // 0x30 Animator
    void *character_renderer; // 0x38 SkinnedMeshRenderer
    void *arms_renderer;      // 0x40 SkinnedMeshRenderer
    void *gloves_renderer;    // 0x48 SkinnedMeshRenderer
    void *untouchable_material;
    void *outline_material;
};

class c_model
{
public:
    char pad0[0x10];
    void *game_object;             // 0x10
    monoArray<void *> *hitboxes;   // 0x18
    c_transform *transform;        // 0x20
    void *animator;                // 0x28
    c_character_bindings *bindings;// 0x30

    c_transform *bone(int human_bone)
    {
        void *anim = animator;
        if (!anim && bindings)
            anim = bindings->animator;
        if (!anim || !base)
            return nullptr;

        // Disassembly of 1.0.0 0x8828724:
        //   sub sp, ...; mov w19, w1; ... bl GetBoneTransformInternal
        //   (x0 = Animator, w1 = HumanBodyBones), no MethodInfo argument.
        // The old native fallback 0x539569C is not GetBoneTransform on this
        // build, so never call it.
        using fn = c_transform *(*)(void *, int);
        fn f = reinterpret_cast<fn>(base + c_offsets->get_bone_transform);
        return f ? f(anim, human_bone) : nullptr;
    }

    c_transform *root_transform()
    {
        if (transform)
            return transform;
        if (bindings)
        {
            // CharacterBindings is a MonoBehaviour; its transform is the model root.
            using get_tr = c_transform *(*)(void *, const void *);
            get_tr f = reinterpret_cast<get_tr>(base + c_offsets->get_transform);
            return f ? f(bindings, nullptr) : nullptr;
        }
        return nullptr;
    }
};

class c_actor
{
public:
    char pad0[0x18];
    monoString *name; // 0x18
};

class c_weapon_instance
{
public:
    char pad0[0x10];
    uint8_t weapon_id;     // 0x10 WeaponId is a byte-backed struct
    char pad11[0x07];      // 0x11..0x17
    void *metadata;        // 0x18
    char pad20[0x30];
    uint16_t metadata_id;  // 0x50
    uint8_t magazine;      // 0x52
    char pad53[1];         // 0x53
    uint16_t reserve;      // 0x54
    float unk58;           // 0x58
};

class c_weapon_part
{
public:
    char pad0[0x10];
    void *active_signal;   // 0x10 Signal<qjf>
    void *uiij;            // 0x18
    void *torc;            // 0x20
    void *suzv;            // 0x28
    void *weapon_context;  // 0x30

    c_weapon_instance *active_weapon()
    {
        if (!this || !base)
            return nullptr;
        using fn = c_weapon_instance *(*)(void *, const void *);
        fn f = reinterpret_cast<fn>(base + game_offsets::managed_rva::kWeaponPartGetActiveWeapon);
        return f ? f(this, nullptr) : nullptr;
    }

    void *context()
    {
        if (!this || !base)
            return nullptr;
        using fn = void *(*)(void *, const void *);
        fn f = reinterpret_cast<fn>(base + game_offsets::managed_rva::kWeaponPartGetContext);
        return f ? f(this, nullptr) : nullptr;
    }
};

class c_parts
{
public:
    char pad0[0x10];
    monoList<void *> *part_list; // 0x10 List<eur>
    char pad18[0x10];

    template <typename T>
    T *find(uintptr_t typeinfo_slot)
    {
        if (!part_list || !part_list->items)
            return nullptr;
        for (int i = 0; i < part_list->size; i++)
        {
            void *item = part_list->items->m_Items[i];
            if (sdk1::same_class(item, typeinfo_slot))
                return (T *)item;
        }
        return nullptr;
    }
};

class c_components
{
public:
    char pad0[0x10];
    monoArray<void *> *arrays[6]; // 0x10 .. 0x38 (0x40 is a Dictionary<Type,chx>)

    template <typename T>
    T *find(uintptr_t typeinfo_slot)
    {
        if (!typeinfo_slot)
            return nullptr;
        for (auto *array : arrays)
        {
            if (!array)
                continue;
            for (int i = 0; i < array->capacity; i++)
            {
                void *item = array->m_Items[i];
                if (sdk1::same_class(item, typeinfo_slot))
                    return (T *)item;
            }
        }
        return nullptr;
    }
};

class c_player_controller
{
public:
    // mfc / NetObject
    char pad0[0x10];
    int32_t net_object_id;  // 0x10 (NetObjectId is an 8-byte struct)
    int32_t owner_id;       // 0x14
    void *world;            // 0x18
    c_components *components; // 0x20
    c_parts *parts;         // 0x28
    char pad30[0x14];
    bool local_owned;       // 0x44
    bool unk45;
    bool unk46;
    char pad47[0x11];

    // ake
    void *oycf;             // 0x58
    monoArray<void *> *positions; // 0x60
    void *nktr;             // 0x68
    c_stats *stats;         // 0x70
    void *lxld;             // 0x78
    void *ldtw;             // 0x80
    void *visibility;       // 0x88
    team_t team;            // 0x90

    bool is_local() const { return local_owned; }
    bool has_stats() const { return stats != nullptr; }
    int health() const { return stats ? stats->hp : 0; }
    int max_health() const { return stats ? stats->max_hp : 0; }
    int armor() const { return stats ? stats->armor : 0; }
    int max_armor() const { return stats ? stats->max_armor : 0; }
    bool alive() const { return health() > 0; }

    Vector3 get_position()
    {
        if (!this || !base)
            return {};
        using fn = Vector3 (*)(void *, const void *);
        fn f = reinterpret_cast<fn>(base + game_offsets::managed_rva::kPlayerGetPosition);
        Vector3 pos = f ? f(this, nullptr) : Vector3{};
        if (pos == Vector3{})
        {
            c_model *m = model();
            if (m && m->root_transform())
                return m->root_transform()->get_position();
        }
        return pos;
    }

    c_model *model()
    {
        if (!components)
            return nullptr;
        c_model *m = components->find<c_model>(game_offsets::typeinfo::kModel);
        if (m)
            return m;
        if (parts)
            return parts->find<c_model>(game_offsets::typeinfo::kModel);
        return nullptr;
    }

    c_weapon_part *weapon_part()
    {
        if (!parts)
            return nullptr;
        return parts->find<c_weapon_part>(game_offsets::typeinfo::kWeaponPart);
    }

    c_weapon_instance *weapon()
    {
        c_weapon_part *part = weapon_part();
        return part ? part->active_weapon() : nullptr;
    }

    c_actor *actor()
    {
        if (components)
        {
            c_actor *a = components->find<c_actor>(game_offsets::typeinfo::kActor);
            if (a)
                return a;
        }
        if (parts)
            return parts->find<c_actor>(game_offsets::typeinfo::kActor);
        return nullptr;
    }
};
#pragma pack()
