
// ================================================================================
// Get latest sources from @imguisource_bot
// Join ImGui Source: t.me/ImGui_Source_FIXNEY
// Join shit src 🧨: t.me/il2cpp_src
// ================================================================================

#pragma once
#include "includes/imgui/imgui.h"

using namespace ImGui;

namespace gui
{
    void render();
    inline ImFont *pixel;
    inline ImFont *font;
}