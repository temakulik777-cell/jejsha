
// ================================================================================
// Community links:
// - @imguisource_bot
// - @ImGui_Source_FIXNEY (ImGui Source)
// - @il2cpp_src (shit src 🧨)
// ================================================================================

#include "chams.h"
#include "sdk/game/c_playercontroller.h"
#include "sdk/game/unity/c_shader.h"
#include "sdk/game/unity/material.h"
#include <sdk/game/il2cpp/il2cpp.h>

static c_material *create_material(int style)
{
    c_shader shader_find;
    static Il2CppClass *material_class{};

    const char *shader_name = "Legacy Shaders/Diffuse";
    switch (style)
    {
    case 1: shader_name = "Hidden/Internal-Colored"; break;
    case 2:
    case 3: shader_name = "Standard"; break;
    case 4: shader_name = "Transparent/Diffuse"; break;
    default: break;
    }

    c_shader *shader = shader_find.find(c_methods->new_str(shader_name));
    if (!shader)
        return nullptr;

    if (!material_class)
        material_class = (Il2CppClass *)il2cpp_class_from_name(dll::unity, oxorany("UnityEngine"), oxorany("Material"));

    if (!material_class)
        return nullptr;

    c_material *mat = (c_material *)il2cpp_object_new(material_class);
    if (!mat)
        return nullptr;

    mat->new_material(shader);

    if (style == 2)
    {
        mat->set_float(c_methods->new_str(oxorany("_SrcBlend")), 1.5f);
        mat->set_float(c_methods->new_str(oxorany("_DstBlend")), 2.0f);
        mat->set_float(c_methods->new_str(oxorany("_Metallic")), 0.5f);
        mat->set_float(c_methods->new_str(oxorany("_Glossiness")), 2.0f);
    }
    else if (style == 3)
    {
        mat->set_float(c_methods->new_str(oxorany("_Metallic")), 5.0f);
        mat->set_float(c_methods->new_str(oxorany("_Glossiness")), 5.0f);
    }

    return mat;
}

static void apply_color(c_material *mat, const float *rgba)
{
    if (!mat)
        return;
    mat->set_color(color_t(rgba[0], rgba[1], rgba[2], rgba[3]));
    mat->set_float(c_methods->new_str(oxorany("_ZTest")), 8.0f);
    mat->set_float(c_methods->new_str(oxorany("_ZWrite")), 0.0f);
}

static void set_character_material(c_player_controller *player, c_material *mat)
{
    if (!player || !mat)
        return;
    auto *model = player->model();
    if (!model || !model->bindings)
        return;
    auto *renderer = (c_renderer *)model->bindings->character_renderer;
    if (renderer)
        renderer->set_material(mat);
}

static void set_gloves_material(c_player_controller *player, c_material *mat)
{
    if (!player || !mat)
        return;
    auto *model = player->model();
    if (!model || !model->bindings)
        return;
    auto *renderer = (c_renderer *)model->bindings->gloves_renderer;
    if (renderer)
        renderer->set_material(mat);
}

static void set_arms_material(c_player_controller *player, c_material *mat)
{
    if (!player || !mat)
        return;
    auto *model = player->model();
    if (!model || !model->bindings)
        return;
    auto *renderer = (c_renderer *)model->bindings->arms_renderer;
    if (renderer)
        renderer->set_material(mat);
}

void chams::enemy(c_player_controller *player)
{
    if (!g.b_players || !player || !player->alive())
        return;

    c_material *mat = create_material(g.i_players);
    if (!mat)
        return;

    if (g.i_players == 4)
        g.m_players[3] = 0.5f;
    apply_color(mat, g.m_players);
    set_character_material(player, mat);
}

void chams::hit(c_player_controller *player)
{
    if (!g.hit_chams || !player)
        return;

    c_material *mat = create_material(g.i_hit);
    if (!mat)
        return;

    if (g.i_hit == 4)
        g.m_hit[3] = 0.5f;
    apply_color(mat, g.m_hit);
    set_character_material(player, mat);
}

void chams::arms(c_player_controller *player)
{
    if (!g.b_gloves || !player)
        return;

    c_material *mat = create_material(g.i_gloves);
    if (!mat)
        return;

    if (g.i_gloves == 4)
        g.m_gloves[3] = 0.5f;
    apply_color(mat, g.m_gloves);
    set_arms_material(player, mat);
    set_gloves_material(player, mat);
}

void chams::local(c_player_controller *player)
{
    if (!g.b_local)
        return;

    c_material *mat = create_material(g.i_local);
    if (!mat)
        return;

    if (g.i_local == 4)
        g.m_local[3] = 0.5f;
    apply_color(mat, g.m_local);
    set_character_material(player, mat);
    this->arms(player);
}

void chams::weapon(c_player_controller *player)
{
    (void)player;
    // Weapon renderers are no longer exposed through a GunController LOD
    // array.  They live inside the weapon part's view hierarchy; disabled
    // until that hierarchy is mapped.
}
