
// ================================================================================
// TG: @imguisource_bot | @ImGui_Source_FIXNEY | @il2cpp_src
// ================================================================================

#include "visual.h"

// Hit events in 1.0.0 are delivered through the obfuscated net-code damage
// pipeline.  The old PlayerHitController/GunController hooks are gone, so the
// visual module is kept as a safe no-op until a 1.0.0 damage event is mapped.

void visual::hits(c_player_controller *)
{
}

void visual::draw_hits()
{
}

void visual::remove(c_player_controller *)
{
}

void visual::hitmarker()
{
}

void visual::third_view(c_transform *)
{
}
