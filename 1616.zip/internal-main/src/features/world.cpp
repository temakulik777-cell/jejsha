
// ================================================================================
// Наш телеграм бот: t.me/imguisource_bot
// Наш канал ImGui Source: t.me/ImGui_Source_FIXNEY
// Второй канал shit src 🧨: t.me/il2cpp_src
// ================================================================================

#include "world.h"

void world::change_world(c_player_controller *local)
{
    (void)local;

    // TODO(1.0.0): the renderer/material hierarchy used by the old world chams
    // path has not been verified on the installed build.  The previous
    // implementation resolved MeshRenderer through the managed Type API and
    // could write back a stale materials array.  Keep this feature disabled
    // instead of exposing a crash from the menu.
    static bool warned = false;
    if (!warned && (g.b_solid || g.b_world))
    {
        warned = true;
        LOGD("world chams disabled: renderer hierarchy not verified");
    }
}

void world::fog()
{
    if (!g.b_fog)
        return;

    using set_bool = void (*)(bool);
    using set_color = void (*)(color_t);
    using set_float = void (*)(float);

    auto sf = reinterpret_cast<set_bool>(base + c_offsets->set_fog);
    auto sc = reinterpret_cast<set_color>(base + c_offsets->set_fog_color);
    auto sd = reinterpret_cast<set_float>(base + c_offsets->set_fog_density);

    if (sf)
        sf(true);
    if (sc)
        sc(float4tocolor(g.m_fog));
    if (sd)
        sd(0.01f);
}

void world::init(c_player_controller *local)
{
    if (!local)
        return;

    this->change_world(local);
    this->fog();
}
