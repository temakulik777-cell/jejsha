
// ================================================================================
// Telegram: @imguisource_bot | Join ImGui Source (t.me/ImGui_Source_FIXNEY) & shit src 🧨 (t.me/il2cpp_src)
// ================================================================================

#include "update.h"
#include "misc.h"
#include "visual.h"
#include "antiaim.h"
#include "world.h"
#include "chams.h"
#include "exploits.h"
#include "esp.h"

#include <atomic>
#include <cstdint>
#include <cstring>
#include <unistd.h>
#include <stdio.h>
#include <sys/mman.h>

#include "includes/egl/memory.hpp"
#include "sdk/game/c_playercontroller.h"
#include "sdk/game/unity/camera.h"

// 1.0.0 player update callback (ake::opmn).
//
// Unity 6000.3 stores the class vtable at Il2CppClass+0x1A0 and uses a
// MethodInfo layout where the method name/class/slot live at +0x18/+0x20/+0x50.
// The old project patched MethodInfo+0x00/+0x08, which is only the first two
// words and is not the callable entry point on this runtime.  We resolve the
// concrete MethodInfo for ake::opmn, then patch the matching VirtualInvokeData
// { methodPtr, MethodInfo* } slot.  The original slot method is called directly.
using player_update_fn = void (*)(void *, const void *);
static player_update_fn old_update = nullptr;

static bool is_code_pointer(uintptr_t pointer)
{
    if (!base)
        return false;
    return pointer >= base + game_offsets::elf::kTextBegin &&
           pointer < base + game_offsets::elf::kTextEnd;
}

// process_vm_readv/writev based access.  The hook installer walks class-owned
// pointer tables before any layout is confirmed, so failed reads must return
// false instead of taking a SIGSEGV.
static bool safe_read(uintptr_t address, void *out, size_t size)
{
    if (!address || !out || !size)
        return false;
    if (memory::perform_mem_rw(address, out, size, false))
        return true;

    // process_vm_readv is normally available on Android, but some vendor
    // kernels/seccomp profiles reject it.  Fall back to a mapped-range check
    // followed by a normal copy for the one-time hook discovery pass.
    if (!(memory::get_protection(address) & PROT_READ))
        return false;
    std::memcpy(out, reinterpret_cast<const void *>(address), size);
    return true;
}

template <typename T>
static bool read_value(uintptr_t address, T &out)
{
    T copy{};
    if (!safe_read(address, &copy, sizeof(T)))
        return false;
    out = copy;
    return true;
}

static bool write_pointer(uintptr_t address, uintptr_t value)
{
    int protection = memory::get_protection(address);
    if (!(protection & PROT_WRITE))
    {
        const uintptr_t page_size = static_cast<uintptr_t>(sysconf(_SC_PAGESIZE));
        const uintptr_t page = address & ~(page_size - 1);
        const int new_protection = (protection ? protection : PROT_READ) | PROT_WRITE;
        if (!memory::protect(page, new_protection))
            return false;
    }

    __atomic_store_n(reinterpret_cast<uintptr_t *>(address), value, __ATOMIC_RELEASE);
    return true;
}

static bool method_info_matches(uintptr_t method_info, uintptr_t target)
{
    if (!method_info)
        return false;

    uintptr_t direct = 0;
    uintptr_t virtual_method = 0;
    return read_value(method_info, direct) &&
           read_value(method_info + sizeof(uintptr_t), virtual_method) &&
           (direct == target || virtual_method == target);
}

void new_update(void *player_ptr, const void *method)
{
    auto *player = static_cast<c_player_controller *>(player_ptr);

    // Let the game finish its own callback first; components and weapon state
    // are then current for the feature code below.
    if (old_update)
        old_update(player_ptr, method);

    static std::atomic<int> update_count{0};
    const int update_index = update_count.fetch_add(1);
    if (update_index < 5)
        LOGD("new_update player=%p method=%p stats=%p", player_ptr, method,
             player ? player->stats : nullptr);

    // Snapshot work is only useful while an ESP consumer is enabled.  Running
    // it unconditionally turned every per-player game update into several
    // managed calls plus a snapshot mutex lock.
    const bool need_snapshot = g.b_esp;
    c_camera camera{};
    if (need_snapshot)
        camera.capture_snapshot();

    if (!player || !player->stats)
        return;

    c_player->collect(player);
    c_player->update();

    if (player->is_local())
    {
        static std::atomic<bool> logged_local{false};
        if (!logged_local.exchange(true))
            LOGD("local player found: %p id=%d owner=%d team=%d hp=%d", player,
                 player->net_object_id, player->owner_id, (int)player->team,
                 player->stats->hp);
    }

    if (player->is_local())
    {
        c_player->local = player;
        c_globals->updateGun();
        c_misc->init(player);
        c_visual->hits(player);
        c_world->init(player);
        c_chams->local(player);
        c_chams->weapon(player);
    }
    else if (c_globals->is_enemy(c_player->local, player))
    {
        c_player->enemy = player;
        c_chams->enemy(player);
    }

    // Keep all managed reads for ESP on this game-thread callback.
    if (need_snapshot)
        c_player->snapshot(player);

    if ((update_index % 600) == 0)
    {
        LOGD("updates=%d players=%zu entity=%zu local=%p enemy=%p snapshots=%zu",
             update_index + 1, c_player->list.size(), c_player->entity.size(),
             c_player->local, c_player->enemy, c_player->get_snapshots().size());
    }
}

static bool patch_player_update(void *klass)
{
    if (!base || !klass)
        return false;

    const uintptr_t class_base = reinterpret_cast<uintptr_t>(klass);
    const uintptr_t target = base + game_offsets::managed_rva::kPlayerUpdateHook;
    const uintptr_t replacement = reinterpret_cast<uintptr_t>(&new_update);

    constexpr size_t method_info_name_offset = 0x18;
    constexpr size_t method_info_class_offset = 0x20;
    constexpr size_t method_info_slot_offset = 0x50;
    constexpr uint16_t invalid_slot = 0xFFFF;
    constexpr size_t vtable_offset = 0x1A0;
    constexpr size_t max_vtable_entries = 256;
    constexpr size_t virtual_invoke_data_size = 2 * sizeof(void *);

    // Find the concrete ake::opmn MethodInfo.  Unity may keep a base MethodInfo
    // in the vtable while the method pointer points at the concrete override, so
    // match the method body address against both MethodInfo pointers.
    uintptr_t target_method_info = 0;
    size_t method_table_header = 0;
    size_t method_table_index = 0;

    for (size_t header = 0; header < vtable_offset && !target_method_info;
         header += sizeof(uintptr_t))
    {
        uintptr_t table = 0;
        if (!read_value(class_base + header, table) || !table)
            continue;

        if (method_info_matches(table, target))
        {
            target_method_info = table;
            method_table_header = header;
            break;
        }

        for (size_t index = 0; index < 512; ++index)
        {
            uintptr_t method_info = 0;
            if (!read_value(table + index * sizeof(uintptr_t), method_info))
                break;
            if (!method_info || is_code_pointer(method_info))
                continue;

            if (method_info_matches(method_info, target))
            {
                target_method_info = method_info;
                method_table_header = header;
                method_table_index = index;
                break;
            }
        }
    }

    uint16_t target_slot = invalid_slot;
    uintptr_t target_class = 0;
    char target_name[32]{};

    if (target_method_info)
    {
        read_value(target_method_info + method_info_slot_offset, target_slot);
        read_value(target_method_info + method_info_class_offset, target_class);

        uintptr_t name_pointer = 0;
        if (read_value(target_method_info + method_info_name_offset, name_pointer) && name_pointer)
        {
            safe_read(name_pointer, target_name, sizeof(target_name) - 1);
            target_name[sizeof(target_name) - 1] = '\0';
        }

        LOGD("player update method: method=%p name=%s class=%p header=0x%zx index=%zu slot=%u",
             reinterpret_cast<void *>(target_method_info), target_name,
             reinterpret_cast<void *>(target_class), method_table_header,
             method_table_index, static_cast<unsigned>(target_slot));
    }

    uintptr_t matched_slot = 0;
    uintptr_t original_method = 0;
    uintptr_t matched_method_info = 0;
    const char *match_reason = nullptr;

    const auto inspect_slot = [&](size_t index, bool authoritative) {
        if (matched_slot)
            return;

        const uintptr_t slot_address = class_base + vtable_offset +
                                       index * virtual_invoke_data_size;

        uintptr_t method_pointer = 0;
        uintptr_t method_info = 0;
        if (!read_value(slot_address, method_pointer) ||
            !read_value(slot_address + sizeof(uintptr_t), method_info) ||
            !is_code_pointer(method_pointer))
            return;

        const bool exact_method_pointer = method_pointer == target;
        const bool exact_method_info =
            (target_method_info && method_info == target_method_info) ||
            method_info_matches(method_info, target);
        const bool trusted_slot = authoritative && is_code_pointer(method_pointer);

        if (!exact_method_pointer && !exact_method_info && !trusted_slot)
            return;

        matched_slot = slot_address;
        original_method = method_pointer;
        matched_method_info = method_info;
        match_reason = exact_method_pointer ? "exact-methodPtr" :
                       (exact_method_info ? "exact-MethodInfo" : "MethodInfo-slot");
    };

    if (target_method_info && target_class == class_base &&
        std::strcmp(target_name, "opmn") == 0 &&
        target_slot != invalid_slot && target_slot < max_vtable_entries)
    {
        inspect_slot(target_slot, true);
    }

    for (size_t index = 0; index < max_vtable_entries && !matched_slot; ++index)
        inspect_slot(index, false);

    if (!matched_slot)
    {
        LOGD("player update hook: vtable slot not found (method=%p)",
             reinterpret_cast<void *>(target_method_info));
        return false;
    }

    if (!old_update)
        old_update = reinterpret_cast<player_update_fn>(original_method);

    if (!write_pointer(matched_slot, replacement))
    {
        LOGD("player update hook: slot %p is not writable",
             reinterpret_cast<void *>(matched_slot));
        return false;
    }

    uintptr_t verify = 0;
    if (!read_value(matched_slot, verify) || verify != replacement)
    {
        write_pointer(matched_slot, original_method);
        old_update = nullptr;
        LOGD("player update hook: verification failed");
        return false;
    }

    LOGD("player update hook ready: reason=%s slot=%p classOffset=0x%zx slotIndex=%u original=%p methodInfo=%p",
         match_reason ? match_reason : "unknown",
         reinterpret_cast<void *>(matched_slot),
         static_cast<size_t>(matched_slot - class_base),
         static_cast<unsigned>((matched_slot - class_base - vtable_offset) /
                               virtual_invoke_data_size),
         reinterpret_cast<void *>(original_method),
         reinterpret_cast<void *>(matched_method_info));
    return true;
}

void update::init()
{
    static bool initialized = false;
    if (initialized)
        return;
    initialized = true;

    // libunity.so is already mapped when the injection thread starts.
    while (!base)
        sleep(1);

    LOGD("update init: base=%p", (void *)base);

    // Resolve the IL2CPP API and attach this worker thread before asking the
    // runtime for ake.  The typeinfo slots in this protected build are not
    // reliable, so sdk1::typeinfo() falls back to il2cpp_class_from_name().
    ::init();
    LOGD("update init: il2cpp api resolved");

    void *klass = nullptr;
    while (!(klass = sdk1::typeinfo(game_offsets::typeinfo::kPlayer)))
    {
        LOGD("update init: ake not resolved yet");
        ::init();
        sleep(1);
    }
    LOGD("update init: ake=%p", klass);

    // One-shot sanity check for the two adjacent string API thunks.  This is
    // intentionally done after typeinfo() attached this thread to IL2CPP.
    static bool string_api_checked = false;
    if (!string_api_checked)
    {
        string_api_checked = true;
        monoString *test = c_methods->new_str("tenmi");
        using string_length_fn = int (*)(void *);
        auto string_length = reinterpret_cast<string_length_fn>(base + 0x6327D50);
        LOGD("string api test: ptr=%p len=%d", test,
             test ? string_length(test) : -1);
    }

    while (!patch_player_update(klass))
    {
        LOGD("update init: hook not installed yet");
        ::init();
        sleep(1);
    }
}
