
// ================================================================================
// -----------------[ TELEGRAM SOURCE ]-----------------
// * BOT:     t.me/imguisource_bot
// * CHANNEL: t.me/ImGui_Source_FIXNEY (ImGui Source)
// * CH 2:    t.me/il2cpp_src (shit src 🧨)
// -----------------------------------------------------
// ================================================================================

#include "misc.h"

void misc::init(c_player_controller *player)
{
    (void)player;
    // Walk/strafer used MovementController/PlayerTranslationParameters in 0.36.
    // In 1.0.0 movement is split into the obfuscated nip/tof components; the
    // exact tuning fields are not mapped yet, so this feature is a safe no-op
    // instead of writing into unrelated memory.
}
