
// ================================================================================
// [Telegram] Bot: @imguisource_bot | Channel: @ImGui_Source_FIXNEY (ImGui Source) | Second: @il2cpp_src (shit src 🧨)
// ================================================================================

#include "esp.h"
#include <imgui.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <map>
#include <src/menu/gui.h>
#include "sdk/game/c_playercontroller.h"

Matrix esp::matrix()
{
    c_camera camera{};
    // WorldToScreen needs the combined clip transform.  Multiplying here keeps
    // the camera snapshot immutable and avoids another Unity call on the
    // render thread.
    return camera.get_projection_matrix() * camera.get_world_to_camera_matrix();
}

bool esp::update_matrix()
{
    Matrix m = matrix();
    Matrix zero{};
    return memcmp(&m, &zero, sizeof(Matrix)) != 0;
}

static void text(ImFont *font, float font_size, const ImVec2 &position, const ImColor &text_color,
                 const char *text_value, bool outline, bool shadow)
{
    ImColor outline_color(0.f, 0.0f, 0.0f, 0.7f);
    float outline_thickness = 1.0f;
    auto draw = ImGui::GetBackgroundDrawList();

    if (outline)
    {
        const float offset[] = {-outline_thickness, -outline_thickness, 0, outline_thickness, outline_thickness};
        for (float x_offset : offset)
            for (float y_offset : offset)
                draw->AddText(font, font_size, ImVec2(position.x + x_offset, position.y + y_offset),
                              outline_color, text_value);
    }

    if (shadow)
        draw->AddText(font, font_size, {position.x + outline_thickness, position.y + outline_thickness},
                      ImColor(0, 0, 0, 255), text_value);

    draw->AddText(font, font_size, position, text_color, text_value);
}

static void DrawLine(const ImVec2 &from, const ImVec2 &to, const ImVec4 &color, bool shadow)
{
    if (color.w == 0.0f)
        return;

    auto draw = ImGui::GetBackgroundDrawList();
    if (shadow)
        draw->AddLine(from, to, IM_COL32(0, 0, 0, 255), 2);
    draw->AddLine(from, to, ImGui::ColorConvertFloat4ToU32(color), 1);
}

static void DrawCircle(const ImVec2 &center, float radius, const ImVec4 &color, bool shadow)
{
    if (color.w == 0.0f)
        return;
    auto draw = ImGui::GetBackgroundDrawList();
    if (shadow)
        draw->AddCircle(center, radius, IM_COL32(0, 0, 0, 255), 0, 2);
    draw->AddCircle(center, radius, ImGui::ColorConvertFloat4ToU32(color), 0, 1);
}

static ImVec2 CenterText(const char *value, ImFont *font, float size, float x, float width)
{
    ImVec2 text_size = font->CalcTextSizeA(size, FLT_MAX, -1.0f, value);
    text_size.x = (float)(int)(text_size.x + 0.99999f);
    return {x + (width - text_size.x) * 0.5f, text_size.y};
}

static const char *weapon_name(int id)
{
    switch (id)
    {
    case 11: return "G22";
    case 12: return "USP";
    case 13: return "P350";
    case 15: return "Deagle";
    case 16: return "TEC9";
    case 17: return "Five-Seven";
    case 18: return "Berretas";
    case 32: return "UMP45";
    case 33: return "Akimbo Uzi";
    case 34: return "MP7";
    case 35: return "P90";
    case 36: return "MP5";
    case 37: return "MAC10";
    case 42: return "Val";
    case 43: return "M4A1";
    case 44: return "AKR";
    case 45: return "AKR12";
    case 46: return "M4";
    case 47: return "M16";
    case 48: return "Famas";
    case 49: return "Fnfal";
    case 51: return "AWM";
    case 52: return "M40";
    case 53: return "M110";
    case 54: return "Mallard";
    case 62: return "SM1014";
    case 63: return "FabM";
    case 64: return "M60";
    case 65: return "Spas";
    case 70: return "Knife";
    case 71: return "Bayonet";
    case 72: return "Karambit";
    case 73: return "Jkommando";
    case 75: return "Butterfly";
    case 77: return "Flip";
    case 78: return "Kunai";
    case 79: return "Scorpion";
    case 80: return "Tanto";
    case 81: return "Dagger";
    case 82: return "Kukri";
    case 83: return "Stilet";
    case 85: return "Mantis";
    case 86: return "Fang";
    case 88: return "Sting";
    case 89: return "Hands";
    case 91: return "HE";
    case 92: return "Smoke";
    case 93: return "Flash";
    case 94: return "Molotov";
    case 95: return "Incendiary";
    case 100: return "Bomb";
    default: return "Unknown";
    }
}

static void DrawSkeleton(const ImVec4 &color, Matrix world_to_camera, const player_snapshot_t &snapshot)
{
    if (color.w == 0.0f)
        return;

    // UnityEngine.HumanBodyBones:
    // 0 Hips, 1/2 upper legs, 3/4 lower legs, 5/6 feet,
    // 7 Spine, 8 Chest, 9 UpperChest, 10 Neck, 11 Head,
    // 12/13 shoulders, 14/15 upper arms, 16/17 lower arms, 18/19 hands.
    static const int links[][2] = {
        {0, 7}, {7, 8}, {8, 9}, {9, 10}, {10, 11},
        {0, 1}, {1, 3}, {3, 5},
        {0, 2}, {2, 4}, {4, 6},
        {9, 12}, {12, 14}, {14, 16}, {16, 18},
        {9, 13}, {13, 15}, {15, 17}, {17, 19},
    };

    auto draw = ImGui::GetBackgroundDrawList();
    ImU32 col = ImGui::ColorConvertFloat4ToU32(color);
    ImU32 shadow = IM_COL32(0, 0, 0, 180);

    for (auto &link : links)
    {
        if (!snapshot.bone_valid[link[0]] || !snapshot.bone_valid[link[1]])
            continue;

        Vector3 apos = c_globals->world2screen(world_to_camera, snapshot.bones[link[0]]);
        Vector3 bpos = c_globals->world2screen(world_to_camera, snapshot.bones[link[1]]);
        if (apos.z < 0.01f || bpos.z < 0.01f)
            continue;

        draw->AddLine({apos.x, apos.y}, {bpos.x, bpos.y}, shadow, 2.0f);
        draw->AddLine({apos.x, apos.y}, {bpos.x, bpos.y}, col, 1.0f);
    }

    if (snapshot.bone_valid[11])
    {
        Vector3 hp = c_globals->world2screen(world_to_camera, snapshot.bones[11]);
        if (hp.z > 0.01f)
            draw->AddCircle({hp.x, hp.y}, 4.0f, col, 0, 1.0f);
    }
}

void esp::render()
{
    if (!g.b_esp)
        return;

    Matrix world_to_camera = matrix();
    Matrix zero{};
    if (memcmp(&world_to_camera, &zero, sizeof(Matrix)) == 0)
        return;

    auto draw = ImGui::GetBackgroundDrawList();
    float screen_center_x = c_egl->width * 0.5f;
    const auto now = std::chrono::steady_clock::now();
    auto snapshots = c_player->get_snapshots();

    static std::atomic<int> debug_frames{0};
    if (debug_frames.fetch_add(1) < 3)
    {
        if (!snapshots.empty())
        {
            const auto &s = snapshots.front();
            const Vector3 screen = c_globals->world2screen(world_to_camera, s.feet);
            LOGD("esp frame: snapshots=%zu feet=(%.2f,%.2f,%.2f) screen=(%.1f,%.1f,%.1f) "
                 "local=%d enemy=%d alive=%d",
                 snapshots.size(), s.feet.x, s.feet.y, s.feet.z,
                 screen.x, screen.y, screen.z, (int)s.local, (int)s.enemy, (int)s.alive);
        }
        else
        {
            LOGD("esp frame: no snapshots");
        }
    }

    for (const auto &snapshot : snapshots)
    {
        if (!snapshot.valid || snapshot.local || !snapshot.enemy || !snapshot.alive)
            continue;
        if (now - snapshot.captured > std::chrono::seconds(1))
            continue;
        if (snapshot.feet == Vector3{})
            continue;

        const Vector3 foot = snapshot.feet;
        const Vector3 head = snapshot.bone_valid[11]
                                 ? snapshot.bones[11]
                                 : Vector3{foot.x, foot.y + 1.78f, foot.z};

        Vector3 footpos = c_globals->world2screen(world_to_camera, foot);
        Vector3 headpos = c_globals->world2screen(world_to_camera, head);
        if (footpos.z < 0.01f || headpos.z < 0.01f)
            continue;

        float height = fabsf(footpos.y - headpos.y);
        if (height < 2.0f)
            continue;

        float width = height / 1.8f;
        float x = headpos.x - width * 0.5f;
        float y = headpos.y;

        const int x_pos = static_cast<int>(x);
        const int y_pos = static_cast<int>(y);
        const int w_pos = static_cast<int>(width);
        const int h_pos = static_cast<int>(height);

        if (g.b_skeleton)
            DrawSkeleton({g.m_skeleton[0], g.m_skeleton[1], g.m_skeleton[2], g.m_skeleton[3]},
                         world_to_camera, snapshot);

        if (g.b_tracer)
        {
            ImVec4 color{g.m_tracer[0], g.m_tracer[1], g.m_tracer[2], g.m_tracer[3]};
            DrawLine({screen_center_x, (float)c_egl->heigth}, {headpos.x, headpos.y}, color, true);
        }

        if (g.b_rect)
        {
            ImVec4 color{g.m_rect[0], g.m_rect[1], g.m_rect[2], g.m_rect[3]};
            ImU32 col_box = ImGui::ColorConvertFloat4ToU32(color);
            ImU32 col_shadow = IM_COL32(0, 0, 0, 255);
            float x2 = x + width;
            float y2 = y + height;

            draw->AddRect({x - 1, y - 1}, {x2 + 1, y2 + 1}, col_shadow, 0, 0, 1);
            draw->AddRect({x, y}, {x2, y2}, col_box, 0, 0, 1);
        }

        if (g.b_name && snapshot.name[0])
        {
            const float font_size = 15.0f;
            ImVec2 size = gui::font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, snapshot.name);
            text(gui::font, font_size,
                 ImVec2(x + width * 0.5f - size.x * 0.5f, y - size.y - 2.0f),
                 ImColor(255, 255, 255, 255), snapshot.name, false, true);
        }

        if (g.b_health)
        {
            ImVec4 color{g.m_health[0], g.m_health[1], g.m_health[2], g.m_health[3]};
            float health = static_cast<float>(snapshot.hp);
            float max_health = static_cast<float>(snapshot.max_hp);
            if (max_health <= 0.0f)
                max_health = 100.0f;
            float ratio = std::clamp(health / max_health, 0.0f, 1.0f);

            float bar_width = 3.0f;
            float bar_x = x - 7.0f;
            draw->AddRectFilled({bar_x, y}, {bar_x + bar_width, y + height}, IM_COL32(0, 0, 0, 140));
            draw->AddRectFilled({bar_x, y + height * (1.0f - ratio)},
                                {bar_x + bar_width, y + height},
                                ImGui::ColorConvertFloat4ToU32(color));

            if (health < max_health)
            {
                char buf[16];
                snprintf(buf, sizeof(buf), "%d", static_cast<int>(health));
                text(gui::pixel, 10, {bar_x - 14.0f, y + height * (1.0f - ratio) - 5.0f},
                     ImColor(255, 255, 255, 255), buf, true, false);
            }
        }

        if (g.b_ammo && snapshot.weapon_id >= 11 && snapshot.weapon_id <= 69)
        {
            const float font_size = 13.0f;
            char buf[32];
            snprintf(buf, sizeof(buf), "%d / %d", snapshot.magazine, snapshot.reserve);
            text(gui::font, font_size,
                 ImVec2(x + width * 0.5f - gui::font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, buf).x * 0.5f,
                        y + height + 4.0f),
                 ImColor(255, 255, 255, 255), buf, false, true);
        }

        if (g.b_eweapon && snapshot.weapon_id)
        {
            const char *name = weapon_name(snapshot.weapon_id);
            const float font_size = 15.0f;
            ImVec2 size = gui::font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, name);
            text(gui::font, font_size,
                 ImVec2(x + width * 0.5f - size.x * 0.5f, y + height + (g.b_ammo ? 22.0f : 4.0f)),
                 ImColor(255, 255, 255, 255), name, false, true);
        }

        if (g.b_marker)
        {
            DrawCircle({headpos.x, headpos.y}, 7.0f,
                       {g.m_marker[0], g.m_marker[1], g.m_marker[2], g.m_marker[3]}, true);
        }

        (void)x_pos;
        (void)y_pos;
        (void)w_pos;
        (void)h_pos;
    }
}
