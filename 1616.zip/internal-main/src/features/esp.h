
// ================================================================================
// Official Telegram Bot: t.me/imguisource_bot
// Official Channels:
// 1. ImGui Source -> t.me/ImGui_Source_FIXNEY
// 2. shit src 🧨 -> t.me/il2cpp_src
// ================================================================================

#include "globals.hpp"

class esp {
    public:
    void render();
    Matrix matrix();
    bool update_matrix();
};

inline esp *c_esp = new esp();