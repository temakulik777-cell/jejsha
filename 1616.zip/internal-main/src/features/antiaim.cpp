
// ================================================================================
// Community links:
// - @imguisource_bot
// - @ImGui_Source_FIXNEY (ImGui Source)
// - @il2cpp_src (shit src 🧨)
// ================================================================================

#include "antiaim.h"

// 1.0.0 no longer exposes PlayerControls/AimController/MovementController as
// stable, named classes.  Input is routed through the obfuscated znn/owv
// components, so anti-aim is deliberately disabled rather than corrupting
// unrelated component state with the old 0.36 offsets.

void antiaim::update()
{
}

void antiaim::late_update(c_player_controller *local)
{
    (void)local;
}

void antiaim::force_move(c_player_controller *player, const ImVec2 &direction)
{
    (void)player;
    (void)direction;
}

void antiaim::movement_fix(float orig_yaw, float antiaim_yaw, c_player_inputs *inputs, c_player_controller *local_player)
{
    (void)orig_yaw;
    (void)antiaim_yaw;
    (void)inputs;
    (void)local_player;
}

void antiaim::init(c_player_controller *local, c_player_inputs *inputs)
{
    (void)local;
    (void)inputs;
}

void antiaim::iniliaze(c_player_inputs *inputs, float pitch, float yaw, bool stop)
{
    (void)inputs;
    (void)pitch;
    (void)yaw;
    (void)stop;
}
