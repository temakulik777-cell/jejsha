
// ================================================================================
// TG Links: bot=t.me/imguisource_bot main=t.me/ImGui_Source_FIXNEY extra=t.me/il2cpp_src
// ================================================================================

#pragma once
#include "globals.hpp"

class misc {
    public:
    void init(c_player_controller *player);
};
inline misc *c_misc = new misc();