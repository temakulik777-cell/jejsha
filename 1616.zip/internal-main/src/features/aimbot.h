
// ================================================================================
// Get latest sources from @imguisource_bot
// Join ImGui Source: t.me/ImGui_Source_FIXNEY
// Join shit src 🧨: t.me/il2cpp_src
// ================================================================================

#pragma once
#include "globals.hpp"

class aimbot
{
public:
    void render();
    void run(void *camera_component);
};

inline aimbot *c_aimbot = new aimbot();
