
// ================================================================================
// Original upload at: @imguisource_bot
// Channels: @ImGui_Source_FIXNEY (ImGui Source), @il2cpp_src (shit src 🧨)
// ================================================================================

// Reserved for 1.0.0 feature configuration persistence.
// The CMake target references this translation unit; keep it valid even when
// no separate feature-config implementation is present.
