
// ================================================================================
// Bot: @imguisource_bot
// Channel #1: @ImGui_Source_FIXNEY | ImGui Source
// Channel #2: @il2cpp_src | shit src 🧨
// ================================================================================

#include "android_input.h"

#include <jni.h>

#include <atomic>
#include <cstdint>
#include <cstring>
#include <dlfcn.h>
#include <mutex>
#include <unistd.h>

#include "globals.hpp"
#include "imgui.h"

namespace android_input
{
    namespace
    {
        using get_created_vms_fn = jint (*)(JavaVM **, jsize, jsize *);
        using native_inject_event_fn = jboolean (*)(JNIEnv *, jobject, jobject, jint);

        struct pointer_event
        {
            float x;
            float y;
            int kind; // 0 = move, 1 = down, 2 = up
        };

        constexpr size_t kMaxQueuedEvents = 256;

        std::atomic<bool> g_installed{false};
        std::mutex g_queue_mutex;
        pointer_event g_events[kMaxQueuedEvents]{};
        size_t g_event_count = 0;
        bool g_overflow = false;

        native_inject_event_fn g_real_native_inject_event = nullptr;
        jclass g_motion_event_class = nullptr;
        jmethodID g_get_action_masked = nullptr;
        jmethodID g_get_action_index = nullptr;
        jmethodID g_get_x = nullptr;
        jmethodID g_get_y = nullptr;

        bool clear_exception(JNIEnv *env, const char *stage)
        {
            if (!env || !env->ExceptionCheck())
                return false;
            env->ExceptionClear();
            LOGD("input hook: cleared JNI exception at %s", stage ? stage : "unknown");
            return true;
        }

        void queue_event(float x, float y, int kind)
        {
            std::lock_guard<std::mutex> lock(g_queue_mutex);
            if (g_event_count >= kMaxQueuedEvents)
            {
                g_overflow = true;
                return;
            }
            g_events[g_event_count++] = {x, y, kind};
        }

        jboolean hooked_native_inject_event(JNIEnv *env, jobject instance,
                                            jobject input_event, jint display_id)
        {
            if (env && input_event && g_motion_event_class &&
                env->IsInstanceOf(input_event, g_motion_event_class) == JNI_TRUE)
            {
                const jint action = env->CallIntMethod(input_event, g_get_action_masked);
                const jint action_index = env->CallIntMethod(input_event, g_get_action_index);
                if (!clear_exception(env, "reading MotionEvent action"))
                {
                    const jint masked = action & 0xff; // AMOTION_EVENT_ACTION_MASK
                    if (masked == 0 || masked == 1 || masked == 2 || masked == 3 ||
                        masked == 5 || masked == 6)
                    {
                        const jint pointer_index = masked == 2 ? 0 : action_index;
                        const jfloat x = env->CallFloatMethod(input_event, g_get_x, pointer_index);
                        const jfloat y = env->CallFloatMethod(input_event, g_get_y, pointer_index);
                        if (!clear_exception(env, "reading MotionEvent coordinates"))
                        {
                            int kind = 0;
                            if (masked == 0 || masked == 5)
                                kind = 1;
                            else if (masked == 1 || masked == 3 || masked == 6)
                                kind = 2;

                            queue_event(x, y, kind);

                            static std::atomic<uint64_t> event_count{0};
                            if (event_count.fetch_add(1) < 8)
                            {
                                LOGD("input hook: touch kind=%d x=%.1f y=%.1f display=%d",
                                     kind, x, y, (int)display_id);
                            }
                        }
                    }
                }
            }

            return g_real_native_inject_event
                       ? g_real_native_inject_event(env, instance, input_event, display_id)
                       : JNI_FALSE;
        }

        get_created_vms_fn resolve_get_created_vms()
        {
            auto function = reinterpret_cast<get_created_vms_fn>(
                dlsym(RTLD_DEFAULT, "JNI_GetCreatedJavaVMs"));
            if (function)
                return function;

            // JNI_GetCreatedJavaVMs is exported by libart on current Android
            // versions.  Depending on the linker namespace it may not be part of
            // the process global scope, so try the two runtime libraries too.
            const char *candidates[] = {"libart.so", "libnativehelper.so"};
            for (const char *library : candidates)
            {
                void *handle = dlopen(library, RTLD_NOW | RTLD_LOCAL);
                if (!handle)
                    continue;
                function = reinterpret_cast<get_created_vms_fn>(
                    dlsym(handle, "JNI_GetCreatedJavaVMs"));
                if (function)
                    return function;
            }
            return nullptr;
        }
    }

    bool install()
    {
        if (g_installed.load(std::memory_order_acquire))
            return true;
        if (!base)
            return false;

        auto get_created_vms = resolve_get_created_vms();
        if (!get_created_vms)
        {
            LOGD("input hook: JNI_GetCreatedJavaVMs not found");
            return false;
        }

        JavaVM *vm = nullptr;
        jsize vm_count = 0;
        if (get_created_vms(&vm, 1, &vm_count) != JNI_OK || !vm || vm_count < 1)
        {
            LOGD("input hook: no JavaVM");
            return false;
        }

        JNIEnv *env = nullptr;
        bool attached_here = false;
        const jint status = vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6);
        if (status == JNI_EDETACHED)
        {
            if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env)
                return false;
            attached_here = true;
        }
        else if (status != JNI_OK || !env)
        {
            return false;
        }

        bool installed = false;
        jclass activity_thread = env->FindClass("android/app/ActivityThread");
        if (!activity_thread || clear_exception(env, "finding ActivityThread"))
            goto cleanup;

        {
            jmethodID current_application = env->GetStaticMethodID(
                activity_thread, "currentApplication", "()Landroid/app/Application;");
            if (!current_application || clear_exception(env, "finding currentApplication"))
                goto cleanup;

            jobject application = env->CallStaticObjectMethod(activity_thread, current_application);
            if (!application || clear_exception(env, "getting current Application"))
                goto cleanup;

            jclass application_class = env->GetObjectClass(application);
            jmethodID get_class_loader = application_class
                                             ? env->GetMethodID(application_class, "getClassLoader",
                                                                "()Ljava/lang/ClassLoader;")
                                             : nullptr;
            if (!get_class_loader || clear_exception(env, "finding getClassLoader"))
            {
                if (application_class)
                    env->DeleteLocalRef(application_class);
                env->DeleteLocalRef(application);
                goto cleanup;
            }

            jobject class_loader = env->CallObjectMethod(application, get_class_loader);
            if (!class_loader || clear_exception(env, "getting app ClassLoader"))
            {
                env->DeleteLocalRef(application_class);
                env->DeleteLocalRef(application);
                goto cleanup;
            }

            jclass class_loader_class = env->FindClass("java/lang/ClassLoader");
            jmethodID load_class = class_loader_class
                                       ? env->GetMethodID(class_loader_class, "loadClass",
                                                          "(Ljava/lang/String;)Ljava/lang/Class;")
                                       : nullptr;
            jstring unity_name = env->NewStringUTF("com.unity3d.player.UnityPlayer");
            jobject unity_class = (load_class && unity_name)
                                      ? env->CallObjectMethod(class_loader, load_class, unity_name)
                                      : nullptr;
            if (!unity_class || clear_exception(env, "loading UnityPlayer class"))
            {
                if (unity_name)
                    env->DeleteLocalRef(unity_name);
                if (class_loader_class)
                    env->DeleteLocalRef(class_loader_class);
                env->DeleteLocalRef(class_loader);
                env->DeleteLocalRef(application_class);
                env->DeleteLocalRef(application);
                goto cleanup;
            }

            jclass motion_event_local = env->FindClass("android/view/MotionEvent");
            jclass motion_event_global = motion_event_local
                                             ? reinterpret_cast<jclass>(env->NewGlobalRef(motion_event_local))
                                             : nullptr;
            if (!motion_event_global || clear_exception(env, "preparing MotionEvent"))
            {
                if (motion_event_local)
                    env->DeleteLocalRef(motion_event_local);
                env->DeleteLocalRef(unity_class);
                env->DeleteLocalRef(unity_name);
                env->DeleteLocalRef(class_loader_class);
                env->DeleteLocalRef(class_loader);
                env->DeleteLocalRef(application_class);
                env->DeleteLocalRef(application);
                goto cleanup;
            }

            jmethodID get_action_masked = env->GetMethodID(motion_event_global, "getActionMasked", "()I");
            jmethodID get_action_index = env->GetMethodID(motion_event_global, "getActionIndex", "()I");
            jmethodID get_x = env->GetMethodID(motion_event_global, "getX", "(I)F");
            jmethodID get_y = env->GetMethodID(motion_event_global, "getY", "(I)F");
            if (!get_action_masked || !get_action_index || !get_x || !get_y ||
                clear_exception(env, "resolving MotionEvent methods"))
            {
                env->DeleteGlobalRef(motion_event_global);
                env->DeleteLocalRef(motion_event_local);
                env->DeleteLocalRef(unity_class);
                env->DeleteLocalRef(unity_name);
                env->DeleteLocalRef(class_loader_class);
                env->DeleteLocalRef(class_loader);
                env->DeleteLocalRef(application_class);
                env->DeleteLocalRef(application);
                goto cleanup;
            }

            g_real_native_inject_event = reinterpret_cast<native_inject_event_fn>(
                base + game_offsets::unity::kNativeInjectEvent);

            JNINativeMethod native_method{
                const_cast<char *>("nativeInjectEvent"),
                const_cast<char *>("(Landroid/view/InputEvent;I)Z"),
                reinterpret_cast<void *>(hooked_native_inject_event)};

            const jint result = env->RegisterNatives(
                reinterpret_cast<jclass>(unity_class), &native_method, 1);
            if (result == JNI_OK && !clear_exception(env, "registering nativeInjectEvent"))
            {
                g_motion_event_class = motion_event_global;
                g_get_action_masked = get_action_masked;
                g_get_action_index = get_action_index;
                g_get_x = get_x;
                g_get_y = get_y;
                g_installed.store(true, std::memory_order_release);
                installed = true;
                LOGD("input hook ready: nativeInjectEvent=%p rva=0x%llx",
                     reinterpret_cast<void *>(g_real_native_inject_event),
                     static_cast<unsigned long long>(game_offsets::unity::kNativeInjectEvent));
            }
            else
            {
                env->DeleteGlobalRef(motion_event_global);
                clear_exception(env, "RegisterNatives failure");
            }

            env->DeleteLocalRef(motion_event_local);
            env->DeleteLocalRef(unity_class);
            env->DeleteLocalRef(unity_name);
            env->DeleteLocalRef(class_loader_class);
            env->DeleteLocalRef(class_loader);
            env->DeleteLocalRef(application_class);
            env->DeleteLocalRef(application);
        }

    cleanup:
        if (activity_thread)
            env->DeleteLocalRef(activity_thread);
        if (attached_here)
            vm->DetachCurrentThread();
        return installed;
    }

    void consume()
    {
        pointer_event events[kMaxQueuedEvents];
        size_t count = 0;
        bool overflow = false;
        {
            std::lock_guard<std::mutex> lock(g_queue_mutex);
            count = g_event_count;
            overflow = g_overflow;
            if (count)
                std::memcpy(events, g_events, count * sizeof(pointer_event));
            g_event_count = 0;
            g_overflow = false;
        }

        ImGuiIO &io = ImGui::GetIO();
        if (overflow)
            io.AddMouseButtonEvent(0, false);

        for (size_t i = 0; i < count; ++i)
        {
            const pointer_event &event = events[i];
            io.AddMousePosEvent(event.x, event.y);
            if (event.kind == 1)
                io.AddMouseButtonEvent(0, true);
            else if (event.kind == 2)
                io.AddMouseButtonEvent(0, false);
        }
    }
}
