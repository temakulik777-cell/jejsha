
// ================================================================================
// Все обновления тут:
// Бот: https://t.me/imguisource_bot
// Канал: https://t.me/ImGui_Source_FIXNEY (ImGui Source)
// Второй: https://t.me/il2cpp_src (shit src 🧨)
// ================================================================================

#pragma once

namespace android_input
{
    // Installs a JNI hook for UnityPlayer.nativeInjectEvent and starts queueing
    // MotionEvents for the render thread.  Safe to call more than once.
    bool install();

    // Feeds queued MotionEvents into ImGui.  Must only be called on the EGL
    // render thread, before ImGui::NewFrame().
    void consume();
}
