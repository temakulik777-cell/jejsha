
// ================================================================================
// Release channel: t.me/ImGui_Source_FIXNEY (ImGui Source)
// Second channel: t.me/il2cpp_src (shit src 🧨)
// Telegram bot: t.me/imguisource_bot
// ================================================================================

#include <setjmp.h>
#include "globals.hpp"
#include <csetjmp>
#include <csignal>
#include <unistd.h>
#include <thread>
#include <cstdio>
#include <cstring>
#include "src/features/exploits.h"

void *globals::get_lazysingleton_typeinfo(uintptr_t addr)
{
    uintptr_t base_addr = (uintptr_t)base;
    void *offset = *reinterpret_cast<void **>(base_addr + addr);
    if (!offset)
        return nullptr;
    void *offset2 = *reinterpret_cast<void **>((uintptr_t)offset + oxorany(0x58));
    if (!offset2)
        return nullptr;
    void *offset3 = *reinterpret_cast<void **>((uintptr_t)offset2 + oxorany(0xb8));
    if (!offset3)
        return nullptr;
    void *instance = *reinterpret_cast<void **>((uintptr_t)offset3 + oxorany(0x0));
    if (!instance)
        return nullptr;
    return instance;
}

void *globals::type_info_instance(uintptr_t addr, uintptr_t field)
{
    uintptr_t base_addr = (uintptr_t)base;
    void *type_info = *reinterpret_cast<void **>(base_addr + addr);
    if (!type_info)
        return nullptr;
    void *static_field = *reinterpret_cast<void **>((uintptr_t)type_info + oxorany(0xb8));
    if (!static_field)
        return nullptr;
    void *instance = *reinterpret_cast<void **>((uintptr_t)static_field + oxorany(0x0));
    if (!instance)
        return nullptr;
    return instance;
}

Vector3 globals::world2screen(const Matrix &viewMatrix, const Vector3 &pos)
{
    float clipX = pos.x * viewMatrix.m00 + pos.y * viewMatrix.m01 + pos.z * viewMatrix.m02 + viewMatrix.m03;
    float clipY = pos.x * viewMatrix.m10 + pos.y * viewMatrix.m11 + pos.z * viewMatrix.m12 + viewMatrix.m13;
    float clipZ = pos.x * viewMatrix.m20 + pos.y * viewMatrix.m21 + pos.z * viewMatrix.m22 + viewMatrix.m23;
    float clipW = pos.x * viewMatrix.m30 + pos.y * viewMatrix.m31 + pos.z * viewMatrix.m32 + viewMatrix.m33;

    if (clipW < 0.001f)
        return {0.f, 0.f, -1.f};

    float ndcX = clipX / clipW;
    float ndcY = clipY / clipW;

    // Callers use .z as a "in front of camera" depth marker.  clipW is positive
    // for points in front of a Unity perspective camera and avoids relying on
    // the platform-specific NDC depth range/reversed-Z convention.
    return {
        (ndcX * 0.5f + 0.5f) * c_egl->width,
        (1.f - (ndcY * 0.5f + 0.5f)) * c_egl->heigth,
        clipW
    };
}

Vector3 world2screen(const Matrix &vm, const Vector3 &vecOrigin) {
    const Quaternion qClip {
        vecOrigin.x * vm.m00 + vecOrigin.y * vm.m01 + vecOrigin.z * vm.m02 + vm.m03,
        vecOrigin.x * vm.m10 + vecOrigin.y * vm.m11 + vecOrigin.z * vm.m12 + vm.m13,
        vecOrigin.x * vm.m20 + vecOrigin.y * vm.m21 + vecOrigin.z * vm.m22 + vm.m23,
        vecOrigin.x * vm.m30 + vecOrigin.y * vm.m31 + vecOrigin.z * vm.m32 + vm.m33,
    };

    const Vector3 vecNormalized {
        qClip.x / (qClip.w > 0 ? qClip.w : 1),
        qClip.y / (qClip.w > 0 ? qClip.w : 1),
        qClip.z / (qClip.w > 0 ? qClip.w : 1)
    };

    return Vector3 {
        (c_egl->width / 2 * vecNormalized.x) + (vecNormalized.x + c_egl->width / 2),
        -(c_egl->heigth / 2 * vecNormalized.y) + (vecNormalized.y + c_egl->heigth / 2),
        vecNormalized.z
    };
}

bool globals::is_bone_visible(Vector3 start, Vector3 end)
{
    raycast_hit_t ray{};
    return !c_methods->linecast(start, end, &ray, 16384);
}

bool globals::is_alive(c_player_controller *player)
{
    return player && player->stats && player->stats->hp > 0;
}

bool globals::is_enemy(c_player_controller *local, c_player_controller *enemy)
{
    if (!local || !enemy)
        return false;

    team_t local_team = local->team;
    team_t enemy_team = enemy->team;

    return local_team != enemy_team;
}

bool globals::is_sniper()
{
    auto weapon = c_player->weapon_instance;
    if (!weapon)
        return false;
    return weapon->weapon_id >= 51 && weapon->weapon_id <= 54;
}

bool globals::holding_gun()
{
    auto weapon = c_player->weapon_instance;
    if (!weapon)
        return false;
    return weapon->weapon_id >= 11 && weapon->weapon_id <= 69;
}

bool globals::is_scoped()
{
    // The old aim/scoped state lived in GunController.  The 1.0.0 weapon part
    // exposes it through an obfuscated state machine which is not mapped yet.
    return false;
}

void player::collect(c_player_controller* player)
{
    if (!player || !player->stats)
        return;

    for (auto *entry : list)
        if (entry == player)
            return;

    list.push_back(player);
}

void player::reset()
{
    local = nullptr;
    for (int i = 0; i < (int)list.size(); i++)
    {
        if (!list[i] || !list[i]->stats)
        {
            list.erase(list.begin() + i);
            i--;
        }
    }
}

void player::after_match()
{
    local = nullptr;
    enemy = nullptr;
    entity.clear();
    list.clear();
    weapon_part = nullptr;
    weapon_instance = nullptr;
    clear_snapshots();
}

void player::update()
{
    local = nullptr;
    entity.clear();

    for (auto *entry : list)
    {
        if (!entry || !entry->stats)
            continue;

        if (entry->is_local())
            local = entry;

        entity.push_back(entry);
    }
}

void player::snapshot(c_player_controller *entry)
{
    if (!entry || !entry->stats)
        return;

    player_snapshot_t snap{};
    snap.player = entry;
    snap.valid = true;
    snap.local = entry->is_local();
    snap.enemy = c_globals->is_enemy(local, entry);
    snap.alive = entry->alive();
    snap.hp = entry->stats->hp;
    snap.max_hp = entry->stats->max_hp;
    snap.armor = entry->stats->armor;

    // All managed calls happen here, on the UnityMain thread. The ImGui render
    // thread only consumes these plain values.
    snap.feet = entry->get_position();

    if (auto *weapon = entry->weapon())
    {
        snap.weapon_id = weapon->weapon_id;
        snap.magazine = weapon->magazine;
        snap.reserve = weapon->reserve;
    }

    // TODO(1.0.0): kActor currently points at stn, which is a request DTO, not
    // the player-name component.  Keep names empty until the real component is
    // identified instead of walking every component with a failed lookup.
    snap.name[0] = '\0';

    if (g.b_skeleton || g.b_marker)
    {
        if (auto *model = entry->model())
        {
            for (int bone = 0; bone < 20; ++bone)
            {
                auto *transform = model->bone(bone);
                if (!transform)
                    continue;
                snap.bones[bone] = transform->get_position();
                snap.bone_valid[bone] = true;
            }
        }
    }

    snap.captured = std::chrono::steady_clock::now();

    std::lock_guard<std::mutex> lock(snapshot_mutex);
    for (auto &existing : snapshots)
    {
        if (existing.player == entry)
        {
            existing = snap;
            return;
        }
    }

    if (snapshots.size() < 128)
        snapshots.push_back(snap);
}

std::vector<player_snapshot_t> player::get_snapshots()
{
    std::lock_guard<std::mutex> lock(snapshot_mutex);
    return snapshots;
}

void player::clear_snapshots()
{
    std::lock_guard<std::mutex> lock(snapshot_mutex);
    snapshots.clear();
}

void globals::updateGun()
{
    if (!c_player->local)
        return;

    c_player->weapon_part = c_player->local->weapon_part();
    c_player->weapon_instance = c_player->local->weapon();
}

void globals::updateTarget()
{
    if (!g.b_esp || !g.b_silent || !g.hitbox)
        return;

    target_t.pos = Vector3{};
    target_t.b_found = false;

    auto *local = c_player->local;
    if (!local)
        return;

    c_camera cam;
    void *native = cam.get_native_main();
    if (!native)
        return;
    Vector3 camera_pos{};
    // The native camera transform is the first component of the view matrix
    // inverse; the player's model root is a close and cheap approximation.
    if (auto *m = local->model(); m && m->root_transform())
        camera_pos = m->root_transform()->get_position();

    float best_dist = FLT_MAX;
    for (auto *player : c_player->entity)
    {
        if (!player || player == local || !is_alive(player) || !is_enemy(local, player))
            continue;

        auto *model = player->model();
        if (!model)
            continue;

        const int head_bones[] = {10, 9};
        const int body_bones[] = {8, 7, 1, 2};
        for (int bone : head_bones)
        {
            auto *tr = model->bone(bone);
            if (!tr)
                continue;
            Vector3 pos = tr->get_position();
            if (!is_bone_visible(camera_pos, pos))
                continue;
            float dist = (pos - camera_pos).length();
            if (dist < best_dist)
            {
                best_dist = dist;
                target_t.pos = pos;
                target_t.b_found = true;
            }
        }
        (void)body_bones;
    }
}

void globals::init()
{
    c_methods->get_width = (decltype(c_methods->get_width))(base + c_offsets->get_width);
    c_methods->get_heigth = (decltype(c_methods->get_heigth))(base + c_offsets->get_heigth);
    c_methods->get_touch = (decltype(c_methods->get_touch))(base + c_offsets->get_touch);
    c_methods->get_count = (decltype(c_methods->get_count))(base + c_offsets->get_count);
    c_methods->linecast = (decltype(c_methods->linecast))(base + c_offsets->linecast);
    c_methods->sphere_cast = (decltype(c_methods->sphere_cast))(base + c_offsets->sphere_cast);
    c_methods->create_string = (decltype(c_methods->create_string))(base + c_offsets->create_string);
    c_methods->set_active = (decltype(c_methods->set_active))(base + c_offsets->set_active);
    c_methods->set_flags = (decltype(c_methods->set_flags))(base + c_offsets->set_flags);
    c_methods->object_instantiate = (decltype(c_methods->object_instantiate))(base + c_offsets->object_instantiate);
    c_methods->object_destroy = (decltype(c_methods->object_destroy))(base + c_offsets->object_destroy);
    c_methods->is_native_object_alive = (decltype(c_methods->is_native_object_alive))(base + c_offsets->is_native_object_alive);
    c_methods->create_string = (decltype(c_methods->create_string))(base + c_offsets->create_string);
}