
// ================================================================================
// TG Links: bot=t.me/imguisource_bot main=t.me/ImGui_Source_FIXNEY extra=t.me/il2cpp_src
// ================================================================================

#pragma once
#include <cstdint>
#include "includes/structs.h"
#include "includes/oxorany/Oxorany.hpp"
#include <android/log.h>
#include "includes/matrix.h"
#include "includes/offsets_1_0_0.hpp"

namespace game_offsets = lemming::offsets;
#include "includes/Obfuscate.hpp"
#include <vector>
#include <mutex>
#include <chrono>
#include <string>
using namespace structs;
inline uintptr_t base;

#define str_(text) \
    []() noexcept { \
        static char buff[sizeof(text)]; \
        if (buff[0] == 0) { \
            memcpy(buff, oxorany(text), sizeof(buff) - 1); \
            buff[sizeof(buff) - 1] = '\0'; \
        } \
        return buff; }()

#define LOGD(fmt, ...) \
    __android_log_print(ANDROID_LOG_DEBUG, "tenmi", fmt, ##__VA_ARGS__)
struct MethodInfo;

class c_player_controller;
class c_playermanager;
class c_player_controls;
class c_game_controller;
class c_photon_player;
class c_component;
class c_weapon_controller;
class c_gun_controller;
class c_weapon_parameters;
class c_gun_parameters;
class c_weapon_part;
class c_weapon_instance;
class globals
{
public:
    bool is_allocated(void *x);
    void *get_lazysingleton_typeinfo(uintptr_t addr);
    void *type_info_instance(uintptr_t addr, uintptr_t field);
    Vector3 world2screen(const Matrix &viewMatrix, const Vector3 &pos);
    bool is_bone_visible(Vector3 start, Vector3 end_pos);
    bool is_alive(c_player_controller *player);
    bool is_enemy(c_player_controller *local, c_player_controller *enemy);
    bool holding_gun();
    bool is_sniper();
    void updateGun();
    void update();
    void updateTarget();
    void init();
    bool is_scoped();
};

inline struct target
{
public:
    bool b_found{};
    Vector3 pos{};
    Vector3 camera_pos{};
    bool fire;
    bool lag;
    c_player_controller *player{};
    bool visible{};
    bool head{};
    int damage{};
    c_player_controller *hitted{};
} target_t;

class methods
{
public:
    int (*get_width)();
    int (*get_heigth)();
    int (*get_count)();
    UnityEngine_Touch_o (*get_touch)(int id);
    void *(*game_controller)();
    bool (*linecast)(Vector3 start, Vector3 end, raycast_hit_t *hitInfo, int layerMask);
    bool (*sphere_cast)(ray_t ray, float radius, raycast_hit_t *hit, float max, int layer);
    monoString *(*create_string)(const char *);
    monoString *new_str(const char *text)
    {
        return create_string ? create_string(text) : nullptr;
    }
    void (*set_active)(void *, bool val);
    void (*set_flags)(void *, uint8_t);
    void (*set_bagcolor)(void *, color_t);
    c_component *(*get_collider)(raycast_hit_t);
    uint8_t (*from_tag)(c_component *);
    void *(*object_instantiate)(void *game_object, Vector3 pos, Quaternion rot);
    void (*object_destroy)(void *game_object, float time);
    bool (*is_native_object_alive)(void *game_object);

};

class offsets
{
public:
    // ---- Standoff 2 1.0.0 (ARM64, libunity.so) ----
    // Managed RVAs below are relative to the libunity.so image base, same as the
    // previous versions of this project. Type/field offsets live in
    // includes/offsets_1_0_0.hpp (namespace lemming::offsets).

    // typeinfo (kept for old call sites; new code uses lemming::offsets::typeinfo)
    const uint32_t c_anticheatmanager = oxorany(0);
    const uint32_t c_player_controls = oxorany(0);
    const uint32_t c_player = oxorany(0xC202058); // ake_TypeInfo

    // inputs
    const uint32_t get_touch = oxorany(0x7B83C34);
    const uint32_t get_count = oxorany(0x7B852F8);

    // screen
    const uint32_t get_width = oxorany(0x760E048);
    const uint32_t get_heigth = oxorany(0x7605164);

    // transform
    const uint32_t get_position = oxorany(0x67EF458);
    const uint32_t set_position = oxorany(0x67F1268);
    const uint32_t get_forward = oxorany(0x67F967C);
    const uint32_t get_up = oxorany(0x6809B90);
    const uint32_t get_euler_angles = oxorany(0x67F7B70);
    const uint32_t set_euler_angles = oxorany(0x67F4378);
    const uint32_t get_rotation = oxorany(0x67EECB8);
    const uint32_t get_bone_transform = oxorany(0x8828724); // Animator.GetBoneTransform

    // Per-player view switching moved to the component architecture in 1.0.0.
    // Kept at zero so stale call sites fail safe instead of jumping to garbage.
    const uint32_t set_tps = oxorany(0);
    const uint32_t set_fps = oxorany(0);
    const uint32_t set_visible = oxorany(0);

    // shader
    const uint32_t find = oxorany(0x75FAF74);

    // material
    const uint32_t get_texture = oxorany(0x760BDB0);
    const uint32_t set_texture = oxorany(0x7611648);
    const uint32_t get_shader = oxorany(0x75F9610);
    const uint32_t set_shader = oxorany(0x7602D8C);
    const uint32_t new_material = oxorany(0x75F3798);
    const uint32_t set_color = oxorany(0x76079E4);   // Material.color setter
    const uint32_t set_int = oxorany(0x760A89C);     // SetInt(string, int)
    const uint32_t set_float = oxorany(0x75F6C44);   // SetFloat(string, float)

    // type
    const uint32_t get_type = oxorany(0x63A1E0C);             // Type.GetType(string)
    const uint32_t find_objects_of_type = oxorany(0x68014D0); // Object.FindObjectsOfType(Type)

    // object
    const uint32_t object_instantiate = oxorany(0x67FBE68);
    const uint32_t object_destroy = oxorany(0x67F6BC4);
    const uint32_t is_native_object_alive = oxorany(0x67FEE48);

    // renderer
    const uint32_t get_material = oxorany(0x75E7C48);
    const uint32_t set_material = oxorany(0x75F2DE8);
    const uint32_t get_materials = oxorany(0x7612138); // get_sharedMaterials
    const uint32_t set_materials = oxorany(0x75EB8A0); // set_sharedMaterials

    // gameobject
    const uint32_t set_active = oxorany(0x67D75B4);

    // fog / render settings (direct UnityEngine.RenderSettings API in 1.0.0)
    const uint32_t rendersettings_manager = oxorany(0);
    const uint32_t call_rendersettings_update = oxorany(0);
    const uint32_t get_fog = oxorany(0x7612954);
    const uint32_t set_fog = oxorany(0x75F0BD4);
    const uint32_t get_fog_color = oxorany(0x760EC5C);
    const uint32_t set_fog_color = oxorany(0x760931C);
    const uint32_t get_fog_density = oxorany(0x760B268);
    const uint32_t set_fog_density = oxorany(0x76096D0);

    // physics
    const uint32_t linecast = oxorany(0x905A5A8);
    const uint32_t sphere_cast = oxorany(0x904D778);

    // character controller
    const uint32_t get_velocity = oxorany(0x905BDCC);

    // raycast delegate: not exposed in the 1.0.0 dump, silent aim is disabled
    const uint32_t ray = oxorany(0);

    // icall
    const uint32_t icall = oxorany(0x6365C88);

    // camera
    const uint32_t get_main = oxorany(0x6D28F70);
    const uint32_t set_fov = oxorany(0x6D29968);
    const uint32_t set_flags = oxorany(0x6D20A88);
    const uint32_t set_bagcolor = oxorany(0x6D13AF8);
    const uint32_t fsdfds = oxorany(0);
    const uint32_t get_projection_matrix_injected = oxorany(0);
    const uint32_t get_world_to_camera_matrix_injected = oxorany(0);

    // component
    const uint32_t get_transform = oxorany(0x67E3358);
    const uint32_t get_game_object = oxorany(0x67D4FBC);

    // other
    // Use il2cpp_string_new rather than new_len: every call site passes a
    // NUL-terminated literal, and this avoids relying on the adjacent
    // new_utf16/new_len thunk order in the stripped build.
    const uint32_t create_string = oxorany(0x6327D58); // il2cpp_string_new

    // api
    const uint32_t il2cpp_domain_get = oxorany(0x6327B70);
    const uint32_t il2cpp_domain_assembly_open = oxorany(0x6327B74);
    const uint32_t il2cpp_assembly_get_image = oxorany(0x6327A18);
    const uint32_t il2cpp_class_from_name = oxorany(0x6327A3C);
    const uint32_t il2cpp_array_new = oxorany(0);
    const uint32_t il2cpp_object_new = oxorany(0x6327D14);
    const uint32_t il2cpp_class_get_method_from_name = oxorany(0x632EC5C);
};

struct Il2CppClass;
class callback
{
public:
    c_player_controller *local_player{};
    c_player_controller *enemy_player{};
    c_playermanager *player_manager{};
    c_player_controls *player_controls{};
    Il2CppClass *playermanager;
    void *weaponry_controller{};
    void *weapon_controller{};
    void *weapon_parameters{};
    c_photon_player *photon{};
};

class egl
{
public:
    int heigth;
    int width;
};

template < typename T >
struct safe_type
{
    T value;
    bool has_value;
};


struct player_snapshot_t
{
    c_player_controller *player{};
    Vector3 feet{};
    Vector3 bones[20]{};
    bool bone_valid[20]{};
    bool valid{};
    bool local{};
    bool enemy{};
    bool alive{};
    int hp{};
    int max_hp{};
    int armor{};
    int weapon_id{};
    int magazine{};
    int reserve{};
    char name[64]{};
    std::chrono::steady_clock::time_point captured{};
};

class player
{
public:
    c_player_controller *enemy{};
    std::vector<c_player_controller *> list{};
    std::vector<c_player_controller *> entity{};
    c_player_controller *local{};

    void reset();
    void collect(c_player_controller *player);
    void after_match();
    void update();
    void snapshot(c_player_controller *player);
    std::vector<player_snapshot_t> get_snapshots();
    void clear_snapshots();

    c_weapon_controller *weapon_controller{};
    c_gun_controller *gun_controller{};
    c_weapon_parameters *weapon_parameters{};
    c_gun_parameters *gun_parameters{};
    c_weapon_part *weapon_part{};
    c_weapon_instance *weapon_instance{};
    c_game_controller *game{};
    c_player_controls *controls{};

private:
    std::mutex snapshot_mutex{};
    std::vector<player_snapshot_t> snapshots{};
};

inline globals *c_globals = new globals();
inline offsets *c_offsets = new offsets();
inline callback *c_callback = new callback();
inline egl *c_egl = new egl();
inline methods *c_methods = new methods();
inline player *c_player = new player();

inline const char *sky_flags[] = {"none", "skybox", "color", "solid", "depth", "nothing"};
inline const char *pitch_[] = {("local"), ("up"), ("down")};
inline const char *yaw_[] = {("local"), ("backward"), ("spiral"), ("chaos")};
inline const char *enemy_[] = {("solid"), ("flat"), ("glass"), ("glow"), ("transparent")};
inline const char *weapon_[] = {("solid"), ("flat"), ("glass"), ("glow"), ("transparent")};
inline const char *local_[] = {("solid"), ("flat"), ("glass"), ("glow"), ("transparent")};
inline const char *hands_[] = {("solid"), ("flat"), ("glass"), ("glow"), ("transparent")};
inline const char *arms_[] = {("solid"), ("flat"), ("glass"), ("glow"), ("transparent")};
inline const char *hit_[] = {("solid"), ("flat"), ("glass"), ("glow"), ("transparent")};
inline const char *knifes[] = {"m9", "karambit", "jkommando", "butterfly", "flip", "kunai", "scorpion", "tanto", "daggers", "kukri", "stilet", "mantis", "fang", "sting", "hands"};

inline struct g_
{
    // esp
    bool b_esp;
    bool b_line;
    bool b_rect;
    bool b_health;
    bool b_name;
    bool b_ammo;
    bool b_skeleton;
    bool b_eweapon;
    float m_ammo[4] = {0.077f, 0.251f, 0.605f, 1.0f};
    float m_health[4] = {0.025f, 0.560f, 0.025f, 1.0f};
    float m_rect[4] = {1.0f, 0.0f, 0.0f, 1.0f};
    float m_skeleton[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    bool b_tracer;
    float m_tracer[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    bool b_marker;
    float m_marker[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    bool b_dmarker;
    bool b_sk;
    float m_sk[4] = {1.0f, 1.0f, 1.0f, 1.0f};

    // ragebot
    bool b_silent;
    bool b_fire;
    bool b_endless;
    bool b_duck;
    bool b_stop;
    int hitchance = 75;
    bool hitbox[4];
    bool b_dt;
    bool predict;
    float factor = 1;
    int fak = 5;
    float dist = 1.65;
    float mom = 2.5;

    // anti aim
    bool b_antiaim;
    int i_pitch = 0;
    int i_yaw = 0;
    bool b_jitter;
    int i_range = 0;
    float f_speed;
    bool b_chaos;
    float f_jitter_speed = 0.3f;
    int frames = 1;

    // misc
    bool b_strafer;
    bool b_walk;
    bool b_third;
    int knife = 0;
    bool b_peek;
    bool b_aspect;
    float f_aspect = 1.5;
    bool b_scope;
    float m_fov = 59.9f;

    // chams
    bool b_players;
    bool b_local;
    bool b_gloves;
    float m_players[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    float m_local[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    float m_gloves[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    float m_hit[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    float m_weapon[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    int i_local = 0;
    int i_players = 0;
    int i_gloves = 0;
    int i_hit = 0;
    int i_weapon = 0;
    bool hit_chams;
    bool weapon_chams;


    // world
    bool b_world;
    bool b_solid;
    bool b_fog;
    float m_world[4] = {0.500f, 0.500f, 0.500f, 0.700f};
    float m_fog[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    float f_start = 5.0f;
    float f_end = 20.0f;
    bool b_sky;
    float m_sky[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    int c_flags = 2;

    // exploits
    bool b_onehit;
    bool b_frate;
    bool b_god;
    bool sethp;
    float dur = 100;
    bool b_weapon;
    bool b_bomb;

    int steps = 2500;
    bool update_matrix{};

} g;
enum class team_t : uint8_t;

inline bool fire{};
inline struct abc
{
    void *player{};
} abcd;
inline bool menu_open = true;
#include "sdk/game/include.h"
