#!/bin/bash

# ================================================================================
# Telegram: @imguisource_bot | Join ImGui Source (t.me/ImGui_Source_FIXNEY) & shit src 🧨 (t.me/il2cpp_src)
# ================================================================================

## -V: create SPIR-V binary
## -x: save binary output as text-based 32-bit hexadecimal numbers
## -o: output file
glslangValidator -V -x -o glsl_shader.frag.u32 glsl_shader.frag
glslangValidator -V -x -o glsl_shader.vert.u32 glsl_shader.vert
